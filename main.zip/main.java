@Override
	public Associate getAssociate(int associateID) throws SQLException {
		Associate associate=new Associate();
		associate.setBankdetails(new BankDetails());
		associate.setSalary(new Salary());
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("select * from  associate where associateID=?");
			pstmt1.setInt(1, associateID);
			ResultSet r=pstmt1.executeQuery();
			PreparedStatement pstmt2=con.prepareStatement("select * from bankdetails where associateID=?");
			pstmt2.setInt(1, associateID);
			ResultSet r2=pstmt2.executeQuery();
			PreparedStatement pstmt3=con.prepareStatement("select * from salary where associateID=?");
			pstmt3.setInt(1, associateID);
			ResultSet r3=pstmt3.executeQuery();
			if(r.next()&&r2.next()&&r3.next()){
				con.commit();
				return new Associate(r.getInt("associateID"),r.getInt("yearlyInvestmentUnder80C"), r.getString("firstName"),r.getString("lastName"), r.getString("department"), r.getString("designation"), r.getString("pancard"), r.getString("emailId"), new Salary(r3.getDouble("basicSalary"), r3.getDouble("conveyenceAllowance"), r3.getDouble("otherAllowance"), r3.getDouble("personalAllowance"), r3.getDouble("monthlyTax"), r3.getDouble("epf"), r3.getDouble("companyPf"), r3.getDouble("gratuity"), r3.getDouble("grossSalary"), r3.getDouble("netSalary"), r3.getDouble("hra")), new BankDetails(r2.getInt("accountNumber"), r2.getString("bankName"),r2.getString("ifscCode")));
			}

			return associate;
		} catch (SQLException e) {

			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
		}
	}

