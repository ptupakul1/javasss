package com.cg.flightapi.controllers;


import java.util.*;

import com.cg.flightapi.beans.Flight;

public class FlightServices {
private static Map<Integer, Flight>flight_list=new HashMap<>();
private static int index=223;
static {
	flight_list.put(222, new Flight(222, 900, 52, 100, "FKLSD", "HYD", "PUNE", "PLANE", "2018/05/06"));
	flight_list.put(223, new Flight(223, 900, 52, 100, "FKLSD", "HYD", "PUNE", "PLANE", "2018/05/06"));
}
 public static List<Flight>list(){
	 return new ArrayList<Flight>(flight_list.values());
 }
 public static int save(Flight f) {
	 index =index+1;
	f.setID(index);
	 flight_list.put(index, f);
	return index;
	 
 }
 public static Flight get(int id) {
		return  flight_list.get(id);
	 
 }
 public static Flight update(int id, Flight f) {
	 f.setID(id);
	 flight_list.put(id, f);
	 return f;
 }
 public static Flight delete(int id) {
	 return flight_list.remove(id);
 }
}
