package com.cg.flightapi.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.flightapi.beans.Flight;


@RequestMapping("api/v1/")
@RestController
@CrossOrigin(origins="*")
public class FlightController {
	@RequestMapping(value="flights", method=RequestMethod.POST)

	public int save(@RequestBody Flight f){
		return FlightServices.save(f);
	}
	
	@RequestMapping(value="flights",method=RequestMethod.GET)
	public List<Flight> get(){
		
		return FlightServices.list();
	}
	@RequestMapping(value="flights/{id}", method=RequestMethod.GET)
	public Flight get(@PathVariable("id") int id) {
		return FlightServices.get(id);
		
	}
	@RequestMapping(value="flights/{id}",method=RequestMethod.DELETE)
	public Flight remove(@PathVariable("id") int id) {
		return FlightServices.delete(id);
		
	}
	@RequestMapping(value="flights/{id}",method=RequestMethod.PUT)
	public Flight update(@PathVariable("id") int id,@RequestBody Flight f) {
		return FlightServices.update(id, f);
		
	}
}
