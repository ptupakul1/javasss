package com.cg.flightsystem.beans;

import java.util.Date;

public class Flight {
	private int ID, price,emptySeats,totalSeats; 
    private String  code,origin,destination,plane_type;   
    private Date departureDate;
	public Flight() {
		super();
	}
	public Flight(int iD, int price, int emptySeats, int totalSeats, String code, String origin, String destination,
			String plane_type, Date departureDate) {
		super();
		ID = iD;
		this.price = price;
		this.emptySeats = emptySeats;
		this.totalSeats = totalSeats;
		this.code = code;
		this.origin = origin;
		this.destination = destination;
		this.plane_type = plane_type;
		this.departureDate = departureDate;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getEmptySeats() {
		return emptySeats;
	}
	public void setEmptySeats(int emptySeats) {
		this.emptySeats = emptySeats;
	}
	public int getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getPlane_type() {
		return plane_type;
	}
	public void setPlane_type(String plane_type) {
		this.plane_type = plane_type;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
    
    
    
     
      
}
