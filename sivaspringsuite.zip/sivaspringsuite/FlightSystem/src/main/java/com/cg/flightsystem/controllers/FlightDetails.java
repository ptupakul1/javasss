package com.cg.flightsystem.controllers;
import org.springframework.web.bind.annotation.RequestMapping;


@RequestMapping
public class FlightDetails {

	

}
