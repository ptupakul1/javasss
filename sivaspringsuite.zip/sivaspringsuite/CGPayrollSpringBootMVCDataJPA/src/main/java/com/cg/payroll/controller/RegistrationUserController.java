package com.cg.payroll.controller;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
@Controller
public class RegistrationUserController {
	@Autowired
	PayrollServices payrollServices;
	@RequestMapping(value="/registerUser")
	public String registerUser(@Valid@ModelAttribute(value="associate")Associate associate,BindingResult result){
		try {if(result.hasErrors())return "registrationPage";
			payrollServices.acceptAssociateDetails(associate);
			return "successPage";
		} catch (PayrollServicesDownException e) {

			return "errorPage";
		}

	}
	@RequestMapping(value="/authUser")
	public String authUser(@Valid@ModelAttribute(value="associate")Associate associate,BindingResult result){
		try {
			if(result.hasFieldErrors("associateID"))return "loginPage";
			Associate associate2=payrollServices.getAssociateDetails(associate.getAssociateID());
			if(associate.getFirstName().equals(associate2.getFirstName()))
				return "successPage";
			return "errorPage";
		} catch (PayrollServicesDownException | AssociateDetailsNotFound e) {
			return "errorPage";
		}

	}
}
