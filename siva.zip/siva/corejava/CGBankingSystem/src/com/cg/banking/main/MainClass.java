package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		File bankfile=new File("d:\\javacrosskilling\\bankfile.txt");
		if (!bankfile.exists())
			bankfile.createNewFile();
		         BankingServicesImpl.deserialization(bankfile);
		int i=0;
		while(i!=15){
			BankingServicesImpl bankingservices=new BankingServicesImpl();
			System.out.println("Choose any option:\n1. For New Customer\n2. For New Account\n3. For Withdraw Amount\n4. For Depoist Amount\n5. For Funds transfer\n6. For Details of coustomer");
			System.out.println("7. For Account Details\n8. For generate New Pin\n9.change Account Pin\n10.AllCustomerDetails\n11.customerAllAccountDetails\n12. AccountAllTransaction\n13.accountStatus\n14.closeAccount\n15. Exit");
			@SuppressWarnings("resource")
			Scanner scr=new Scanner(System.in);
			
			try{

				i= scr.nextInt();

				switch (i) {
				case 1:
					System.out.println("Enter first name:\t");
					String firstName= scr.next();
					
					System.out.println("Enter last name:\t");
					String lastName= scr.next();
					System.out.println("Enter emailId:\t");
					String emailId= scr.next();
					System.out.println("Enter PancardNO:\t");
					String panCard= scr.next();
					System.out.println("Enter localAddressCity:\t");
					String localAddressCity= scr.next();
					System.out.println("Enter localAddressState:\t");
					String localAddressState= scr.next();
					System.out.println("Enter localAddresspincode:\t");
					int localAddressPinCode= scr.nextInt();
					System.out.println("Enter HomeAddressCity:\t");
					String homeAddressCity= scr.next();
					System.out.println("Enter HomeAddressState:\t");
					String homeAddressState= scr.next();
					System.out.println("Enter HomeAddresspincode:\t");
					int homeAddressPinCode= scr.nextInt();
					System.out.println("Your CustomerId is:" +bankingservices.acceptCustomerDetails(firstName, lastName, emailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode));
					break;
				case 2:
					System.out.println("Enter CustomerId\t:");
					int customerId=scr.nextInt();
					System.out.println("Enter accountType\t:");
					String accountType=scr.next();
					System.out.println("Enter IntialBalance\t:");
					float initBalance=scr.nextFloat();
					System.out.println("your new accountNO" +bankingservices.openAccount(customerId, accountType, initBalance));
					break;
				case 3: 
					System.out.println("Enter CustomerId:\t");
					int customerId1=scr.nextInt();
					System.out.println("Enter accountNO");
					long accountNO=scr.nextLong();
					System.out.println("Enter Withdraw amount:\t");
					float amount=scr.nextFloat();
					System.out.println("Enter pinnumber:\t");
					int pinNumber=scr.nextInt();
					System.out.println(bankingservices.withdrawAmount(customerId1, accountNO, amount, pinNumber));
					break;
				case 4:
					System.out.println("Enter CustomerId:\t");
					int customerId2=scr.nextInt();
					System.out.println("Enter accountNO");
					long accountNO1=scr.nextLong();
					System.out.println("Enter deposit amount:\t");
					float amount2=scr.nextFloat();
					System.out.println(bankingservices.depositAmount(customerId2, accountNO1, amount2));
					break;
				case 5:
					System.out.println("Enter ToCustomerId:");
					int customerIdTo=scr.nextInt();
					System.out.println("Enter ToCustomer accountNo:");
					int accountNo2=scr.nextInt();
					System.out.println("Enter fromCustomerId:");
					int customerIdFrom=scr.nextInt();
					System.out.println("Enter fromCustomer accountNo:");
					int accountNo3=scr.nextInt();
					System.out.println("Enter transfer amount:\t");
					float transferAmount=scr.nextFloat();
					System.out.println("Enter pinnumber:\t");
					int pinNumber1=scr.nextInt();
					System.out.println(bankingservices.fundTransfer(customerIdTo, accountNo2, customerIdFrom, accountNo3, transferAmount, pinNumber1));
					break;
				case 6:
					System.out.println("Enter customerId:");
					int customerid=scr.nextInt();
					System.out.println(bankingservices.getCustomerDetails(customerid));
					break;
				case 7:
					System.out.println("Enter customerId:");
					int customerId11=scr.nextInt();
					System.out.println("Enter accoun Number:");
					long accountNo=scr.nextLong();
					System.out.println(bankingservices.getAccountDetails(customerId11, accountNo));
					break;
				case 8:
					System.out.println("Enter customerId:");
					int customerId111=scr.nextInt();
					System.out.println("Enter accoun Number:");
					long accountNo1=scr.nextLong();
					System.out.println(bankingservices.generateNewPin(customerId111, accountNo1));
					break;
				case 9:	
					System.out.println("Enter customerId:");
					int customerId1111=scr.nextInt();
					System.out.println("Enter accoun Number:");
					long accountNo11=scr.nextLong();
					System.out.println("Enter oldPinnumber");
					int oldPinNumber=scr.nextInt();
					System.out.println("Enter newPinnumber");
					int newPinNumber=scr.nextInt();
					System.out.println(bankingservices.changeAccountPin(customerId1111, accountNo11, oldPinNumber, newPinNumber));
					break;
				case 10:
					List<Customer> customer=bankingservices.getAllCustomerDetails();
					for (Customer	c2	: customer)
						System.out.println(c2);
					break;
				case 11: 
					System.out.println("Enter customerId:");
					int customerId11111=scr.nextInt();
					List<Account> account=bankingservices.getcustomerAllAccountDetails(customerId11111);
					for (Account account2	: account) 
						System.out.println(account2);
					break;
				case 12: 
					System.out.println("Enter customerId:");
					int customerId111111=scr.nextInt();
					System.out.println("Enter accoun Number:");
					long accountNo111=scr.nextLong();
					List< Transaction> transaction=bankingservices.getAccountAllTransaction(customerId111111, accountNo111);
					for (Transaction	transaction2	: transaction) 
						System.out.println(transaction2);
					break;
				case 13:
					System.out.println("Enter customerId:");
					int customerId1111111=scr.nextInt();
					System.out.println("Enter accoun Number:");
					long accountNo1111=scr.nextLong();
					System.out.println(bankingservices.accountStatus(customerId1111111, accountNo1111));
					break;
				case 14:

					System.out.println("Enter customerId:");
					int customerId11111111=scr.nextInt();
					System.out.println("Enter accoun Number:");
					long accountNo11111=scr.nextLong();
					System.out.println(bankingservices.closeAccount(customerId11111111, accountNo11111));
				case 15:
					BankingServicesImpl.serialization(bankfile);
					break;
					default:
						System.out.println("\n\nInvalid choose\n");
				}


			}
			catch (InputMismatchException f) {
				f.printStackTrace();
			}
			catch(Exception e) {
				e.printStackTrace();


			}




		}
	}
}