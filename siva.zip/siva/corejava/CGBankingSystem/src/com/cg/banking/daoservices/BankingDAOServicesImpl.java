package com.cg.banking.daoservices;

import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;


public class BankingDAOServicesImpl implements BankingDAOServices{
	public static HashMap<Integer,Customer>customerlist=new HashMap<>();


	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER);
		customerlist.put(BankingUtility.CUSTOMER_ID_COUNTER++, customer);
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER);

		account.setStatus("Active");
		generatePin(customerId, account);
		getCustomer(customerId).getAccountlist().put(BankingUtility.ACCOUNT_ID_COUNTER, account);
		insertTransaction(customerId, account.getAccountNo(), new Transaction(account.getAccountBalance(), "Deposit"));
		return customerlist.get(customerId).getAccountlist().get(BankingUtility.ACCOUNT_ID_COUNTER++).getAccountNo(); 

	}


	@Override
	public boolean updateAccount(int customerId, Account account) {
		if(customerlist.get(customerId).getAccountlist().replace(account.getAccountNo(), account)!=null) return true;

		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		account.setPinNumber(BankingUtility.pinnumber++);
		updateAccount(customerId, account);
		//System.out.println(account.getPinNumber());
		return account.getPinNumber();
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingUtility.TRANSACTION_ID);
		getAccount(customerId, accountNo).getTransactionlist().put(BankingUtility.TRANSACTION_ID++, transaction);
		return true;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		if(customerlist.remove(customerId)!=null)
			return true;
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		if(getCustomer(customerId).getAccountlist().remove(accountNo)!=null)
			return true;
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customerlist.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return getCustomer(customerId).getAccountlist().get(accountNo);

	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList(customerlist.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList(getCustomer(customerId).getAccountlist().values());
	}

	@Override
	public List<Transaction>getTransactions(int customerId, long accountNo) {
		return new ArrayList(getAccount(customerId, accountNo).getTransactionlist().values());

	}
	public static void doserialization(File file) throws IOException{
		if(customerlist.size()==0)
			return ;
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
			dest.writeObject(customerlist);	

		}
	}
	public  static void doDeserialization(File file) throws IOException, ClassNotFoundException{
		if(file.length()==0)
			return;
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(file))){
			customerlist= (HashMap<Integer, Customer>) src.readObject();	
			BankingUtility.CUSTOMER_ID_COUNTER= Collections.max(customerlist.keySet())+1;
					for(Integer key:customerlist.keySet()){
				//if(!customerlist.get(key).getAccountlist().keySet().isEmpty())
			       
			}
		}
	}

}
