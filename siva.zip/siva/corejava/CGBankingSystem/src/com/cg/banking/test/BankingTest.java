package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;

public class BankingTest {
	private static BankingServices banking;


	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		banking= new BankingServicesImpl();

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		banking=null;
	}

	@Before
	public void setUp() throws Exception {
		Customer c=new Customer("sds", "asa", "sa", "sdf", new Address(55, "sd", "as"), new Address(55, "sd", "aa"));
		c.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		Account a=new Account("Savings", 1000);
		a.setPinCounter(3);
		a.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		a.setPinNumber(BankingUtility.pinnumber++);
		a.setStatus("Active");
		c.getAccountlist().put(a.getAccountNo(),a );
		Transaction t=new Transaction(100, "Deposit");
		t.setTransactionId(BankingUtility.TRANSACTION_ID++);
		c.getAccountlist().get(a.getAccountNo()).getTransactionlist().put(t.getTransactionId(), t);
	   BankingDAOServicesImpl.customerlist.put(c.getCustomerId(), c);
	   //Customer c2=new Customer("sd","dsa","ad","sa",new Address(4,"sd","s"),new Address(4, "s", "sa"));
	   //c2.setCustomerId(1112);
	   //BankingDAOServicesImpl.customerlist.put(c2.getCustomerId(), c2);
	  // Customer c3=new Customer(BankingUtility.CUSTOMER_ID_COUNTER++, "df", "sd", "DS", "SDS", new Address(1, "sdd", "sd"), new Address(55,"sd","sd"), new HashMap<>());
	   // c3.getAccountlist().put(778l, new Account(1002, 3, "Savings", "active", 100, 778, new HashMap<>()));
	   //BankingDAOServicesImpl.customerlist.put(c3.getCustomerId(), c3);
	}

	@After
	public void tearDown() throws Exception {
		banking.getAllCustomerDetails().clear();
		BankingUtility.ACCOUNT_ID_COUNTER=777;
	     BankingUtility.CUSTOMER_ID_COUNTER=1111;
	     BankingUtility.pinnumber=1001;
	     BankingUtility.TRANSACTION_ID=1111;
	}

	@Test
	public void acceptCustomerDetailsvalid() throws BankingServicesDownException {
		assertEquals(1112,banking.acceptCustomerDetails("siva", "df", "SD", "SA", "DS", "SD", 45, "DA", "SA", 45));
	}
	
	@Test
	public void  openAccountvalid() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException {
		assertEquals(778,banking.openAccount(1111, "Current", 100));
		
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void  openAccountInvalidaccount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		banking.openAccount(1111,"vings", 100);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void  openAccountInvalidCustomer() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		banking.openAccount(1113,"Savings", 100);
	}
	@Test(expected=InvalidAmountException.class)
	public void  openAccountInvalidAmount() throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		banking.openAccount(1111,"Savings", 99f);
	}
	@Test
	public void  depositAmountValid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException  {
		assertEquals(1003,banking.depositAmount(1111, 777l, 3),0);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void  depositAmountInvalidCustomer() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException  {
		banking.depositAmount(111, 778l, 3);
	}
	@Test(expected=AccountNotFoundException.class)
	public void  depositAmountInvalidAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException  {
		banking.depositAmount(1111, 77l, 3);
	}
	@Test(expected=AccountBlockedException.class)
	public void  depositAmountBlockedException() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException  {
		banking.getAccountDetails(1111, 777).setStatus("Blocked");
		banking.depositAmount(1111, 777l, 3);
	}
	@Test
	public void   withdrawAmountValid() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException   {
		assertEquals(500,banking. withdrawAmount(1111, 777, 500, 1001),0);
	}
	@Test
	public void   withdrawAmountInvalid() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException   {
		assertNotEquals(5003,banking. withdrawAmount(1111, 777, 500, 1001),0);
	}
	@Test(expected=InsufficientAmountException.class)
	public void   withdrawAmountInsufficient() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException   {
		banking. withdrawAmount(1111, 777, 1500, 1001);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void   withdrawAmountInvalidPin() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException   {
		banking. withdrawAmount(1111, 777, 500, 100);
	}
	/*@Test(expected=AccountBlockedException.class)
	public void   withdrawAmountBlocked() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException   {
		assertEquals(500,banking.withdrawAmount(1111, 777, 500, 1001),0);
	}*/
	@Test
	public void  getCustomerDetails() throws CustomerNotFoundException, BankingServicesDownException{
		Customer c=new Customer("sds", "asa", "sa", "sdf", new Address(55, "sd", "as"), new Address(55, "sd", "aa"));
		c.setCustomerId(1111);
		Account a=new Account("Savings", 1000);
		a.setPinCounter(3);
		a.setAccountNo(777);
		a.setPinNumber(1001);
		a.setStatus("Active");
		c.getAccountlist().put(a.getAccountNo(),a );
		Transaction t=new Transaction(100, "Deposit");
		t.setTransactionId(1111);
		c.getAccountlist().get(a.getAccountNo()).getTransactionlist().put(t.getTransactionId(), t);
		assertEquals(c,banking.getCustomerDetails(1111));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void  getCustomerDetailsNotfound() throws CustomerNotFoundException, BankingServicesDownException{
		Customer c=new Customer("sds", "asa", "sa", "sdf", new Address(55, "sd", "as"), new Address(55, "sd", "aa"));
		c.setCustomerId(1111);
		Account a=new Account("Savings", 1000);
		a.setPinCounter(3);
		a.setAccountNo(777);
		a.setPinNumber(1001);
		a.setStatus("Active");
		c.getAccountlist().put(a.getAccountNo(),a );
		Transaction t=new Transaction(100, "Deposit");
		t.setTransactionId(1111);
		c.getAccountlist().get(a.getAccountNo()).getTransactionlist().put(t.getTransactionId(), t);
		banking.getCustomerDetails(1112);
	}
	@Test
	public void   getAccountDetails() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException   {
		Account a=new Account("Savings", 1000);
		a.setPinCounter(3);
		a.setAccountNo(777);
		a.setPinNumber(1001);
		a.setStatus("Active");
	    Transaction t=new Transaction(100, "Deposit");
		t.setTransactionId(1111);
		a.getTransactionlist().put(1111, t);
		assertEquals(a,banking. getAccountDetails(1111, 777));
	}
	@Test(expected=AccountNotFoundException.class)
	public void   getAccountDetailsInvalid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException   {
		Account a=new Account("Savings", 1000);
		a.setPinCounter(3);
		a.setAccountNo(777);
		a.setPinNumber(1001);
		a.setStatus("Active");
	    Transaction t=new Transaction(100, "Deposit");
		t.setTransactionId(1111);
		a.getTransactionlist().put(1111, t);
		banking. getAccountDetails(1111, 778);
	}
	@Test
	public void   generateNewPin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		assertEquals( 1002,banking.generateNewPin(1111, 777));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void   generateNewPinInvalid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		 banking.generateNewPin(111, 777);
	}
	@Test
	public void   changeAccountPin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException {
		 assertTrue(banking.changeAccountPin(1111, 777, 1001,1015));
	}
	@Test(expected=InvalidPinNumberException.class)
	public void changeAccountPinInvalid() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException {
		 banking.changeAccountPin(1111, 777, 1001,111);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void changeAccountPinInvalidCustomer() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException {
		 banking.changeAccountPin(111, 777, 1001,1117);
	}
	@Test(expected=AccountNotFoundException.class)
	public void changeAccountPinInvalidAccount() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException {
		 banking.changeAccountPin(1111, 77, 1001,1117);
	}
	@Test
	public void  getcustomerAllAccountDetails() throws BankingServicesDownException, CustomerNotFoundException {
		List<Account> aa=new  ArrayList<>();
		Account a=new Account("Savings", 1000);
		a.setPinCounter(3);
		a.setAccountNo(777);
		a.setPinNumber(1001);
		a.setStatus("Active");
	    Transaction t=new Transaction(100, "Deposit");
		t.setTransactionId(1111);
		a.getTransactionlist().put(1111, t);
		aa.add( a);
		assertEquals(aa,banking.getcustomerAllAccountDetails(1111));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void  getcustomerAllAccountDetailsInvalid() throws BankingServicesDownException, CustomerNotFoundException {
		banking.getcustomerAllAccountDetails(111);
	}
	@Test
	public void   getAccountAllTransaction() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		List<Transaction> t=new ArrayList<>();
		Transaction tt=new Transaction(100, "Deposit");
		tt.setTransactionId(1111);
		t.add(tt);
		assertEquals(t, banking.getAccountAllTransaction(1111, 777));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void   getAccountAllTransactionCustomerNotfound() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
       banking.getAccountAllTransaction(111, 777);
	}
	@Test(expected=AccountNotFoundException.class)
	public void   getAccountAllTransactionAccountNotfound() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
       banking.getAccountAllTransaction(1111, 77);
	}
	@Test
	public void   getAllCustomerDetails() throws BankingServicesDownException{
		List<Customer> cc=new ArrayList<>();
		Customer c=new Customer("sds", "asa", "sa", "sdf", new Address(55, "sd", "as"), new Address(55, "sd", "aa"));
		c.setCustomerId(1111);
		Account a=new Account("Savings", 1000);
		a.setPinCounter(3);
		a.setAccountNo(777);
		a.setPinNumber(1001);
		a.setStatus("Active");
		c.getAccountlist().put(a.getAccountNo(),a );
		Transaction t=new Transaction(100, "Deposit");
		t.setTransactionId(1111);
		c.getAccountlist().get(a.getAccountNo()).getTransactionlist().put(t.getTransactionId(), t);
		cc.add(c);
		assertEquals(cc,banking.getAllCustomerDetails());
	}
	@Test
	public void   accountStatus() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		assertEquals("Active",banking.accountStatus(1111, 777));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void accountStatusInvalidCustomer() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		banking.accountStatus(111,777);
	}
	@Test(expected=AccountNotFoundException.class)
	public void accountStatusInvalidAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		banking.accountStatus(1111,77);
	}
	@Test
	public void   closeAccount() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		assertTrue(banking.closeAccount(1111, 777));
	}
	@Test(expected=CustomerNotFoundException.class)
	public void   closeAccountInvalid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		banking.closeAccount(11, 777);
	}
}
