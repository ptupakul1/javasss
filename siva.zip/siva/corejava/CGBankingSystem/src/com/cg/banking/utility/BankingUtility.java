package com.cg.banking.utility;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=1111;
    public static long ACCOUNT_ID_COUNTER=777;
	public static int TRANSACTION_ID=1111;
	public static int pinnumber=1001;

}
