package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		   try {
			ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
			BankingServices bankingServices=(BankingServices) applicationContext.getBean("bankingServices");
         
				System.out.println(bankingServices.acceptCustomerDetails("ss", "sd", "sdq", "sd", "sdq", "sd", 56, "sd", "fs", 56));
			System.out.println(bankingServices.openAccount(1,"Savings",1000));
		   } catch (BankingServicesDownException | InvalidAmountException | CustomerNotFoundException | InvalidAccountTypeException e) {
					e.printStackTrace();
			}
		
		  



	}
}