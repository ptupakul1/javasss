package com.cg.payroll.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private PayrollDAOServices daoServices;
	public PayrollServicesImpl() {}
   
	public PayrollServicesImpl(PayrollDAOServices daoServices) {
		super();
		this.daoServices = daoServices;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public int acceptAssociateDetails( Associate associte)throws PayrollServicesDownException{
		return daoServices.save(associte).getAssociateID();
		
	}


	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public double calaculateNetSalary(int associateID) throws AssociateDetailsNotFound,PayrollServicesDownException {
		Associate associate=this.getAssociateDetails(associateID);
		associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary()*0.3);
		associate.getSalary().setConveyenceAllowance(associate.getSalary().getBasicSalary()*0.2);
		associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary()*0.1);
		associate.getSalary().setHra(associate.getSalary().getBasicSalary()*0.25);
		associate.getSalary().setGratuity(associate.getSalary().getBasicSalary()*0.05);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		double annualSalary=associate.getSalary().getGrossSalary()*12;
		double unTaxable=associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
		double taxable,tax=0;
		if (unTaxable>150000){
			double taxable1=unTaxable-150000;
			taxable=annualSalary-150000+taxable1;
		}
		else	{
			taxable=annualSalary-unTaxable;
		}
		if (taxable>1000000){
			double taxable2=taxable-1000000;
			tax=tax+(taxable2*0.3f);
			taxable=taxable-taxable2;
		}
		if(taxable>500000&&taxable<=1000000){
			double taxable2=(taxable-500000);
			tax=tax+(taxable2*0.2f);
			taxable=taxable-taxable2;		}

		if(taxable>250000&&taxable<=500000){
			double taxable2=(taxable-250000);
			tax=tax+(taxable2*0.1f);
			taxable=taxable-taxable2;	
		}
		associate.getSalary().setMonthlyTax(tax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		daoServices.saveAndFlush(associate);
		return associate.getSalary().getNetSalary();


	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFound,PayrollServicesDownException {

		if( !daoServices.exists(associateID))
			throw new AssociateDetailsNotFound("Associate not found");
		return daoServices.findOne(associateID);
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public List<Associate> getAllAssociatesDetails()throws PayrollServicesDownException {

		return daoServices.findAll();
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean deleteAssociate(int associateId) throws AssociateDetailsNotFound,PayrollServicesDownException {

		if(daoServices.exists(associateId)){
			daoServices.delete(associateId);
			return true;
		}
		return false;
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public boolean updateAssociatedetails(int associateID, String firstName, String lastName, String emailId,
			String department, String designation, String pancard, int yearlyInvestmentUnder80C, double basicSalary,
			double epf, double companyPf, int accountNumber, String bankName, String ifscCode)
					throws AssociateDetailsNotFound,PayrollServicesDownException {
		Associate associate=new Associate(associateID, yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
		if(daoServices.exists(associateID)){
		daoServices.saveAndFlush(associate);
		return true;
		}
		return false;
	}

	/*public double calaculateNetSalary(int associateID)throws AssociateDetailsNotFound{
		Associate associate=this.getAssociateDetails(associateID);
		associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary()*0.3);
		associate.getSalary().setConveyenceAllowance(associate.getSalary().getBasicSalary()*0.2);
		associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary()*0.1);
		associate.getSalary().setHra(associate.getSalary().getBasicSalary()*0.25);
		associate.getSalary().setGratuity(associate.getSalary().getBasicSalary()*0.05);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		double annualSalary=associate.getSalary().getGrossSalary()*12;
		double unTaxable=associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
		double taxable,tax=0;
		if (unTaxable>150000){
			double taxable1=unTaxable-150000;
			taxable=annualSalary-150000+taxable1;
		}
		else	{
			taxable=annualSalary-unTaxable;
		}
		if (taxable>1000000){
			double taxable2=taxable-1000000;
			tax=tax+(taxable2*0.3f);
			taxable=taxable-taxable2;
		}
		if(taxable>500000&&taxable<=1000000){
			double taxable2=(taxable-500000);
			tax=tax+(taxable2*0.2f);
			taxable=taxable-taxable2;		}

		if(taxable>250000&&taxable<=500000){
			double taxable2=(taxable-250000);
			tax=tax+(taxable2*0.1f);
			taxable=taxable-taxable2;	
		}
		associate.getSalary().setMonthlyTax(tax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		daoServices.updateAssociate(associate);
		return associate.getSalary().getNetSalary();

	}



	public Associate getAssociateDetails(int associateID)throws AssociateDetailsNotFound{
	Associate associate=daoServices.getAssociate(associateID);
	     if(associate==null)
	    	throw  new AssociateDetailsNotFound("notasassdss found");
		return associate;
	}

	public List<Associate> getAllAssociatesDetails(){
		return daoServices.getAssociates();
	}
	public boolean deleteAssociate(int associateId)throws AssociateDetailsNotFound{
		getAssociateDetails(associateId);
		return daoServices.deleteAssociate(associateId);
	}
	public boolean updateAssociatedetails(int associateID,String firstName, String lastName,String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,double basicSalary,double epf, double companyPf,int accountNumber, 
			String bankName, String ifscCode)throws AssociateDetailsNotFound{
		getAssociateDetails(associateID);
		return daoServices.updateAssociate(new Associate(associateID, yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));

	}

	 */



}
