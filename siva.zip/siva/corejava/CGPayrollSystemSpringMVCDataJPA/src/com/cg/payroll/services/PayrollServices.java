package com.cg.payroll.services;

import java.util.List;
import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public interface PayrollServices {

	int acceptAssociateDetails(Associate associate)throws PayrollServicesDownException;

	double calaculateNetSalary(int associateID)throws AssociateDetailsNotFound,PayrollServicesDownException;

	Associate getAssociateDetails(int associateID)throws AssociateDetailsNotFound,PayrollServicesDownException;

	List<Associate> getAllAssociatesDetails()throws PayrollServicesDownException;
    boolean deleteAssociate(int associateId)throws AssociateDetailsNotFound,PayrollServicesDownException;
    public boolean updateAssociatedetails(int associateID,String firstName, String lastName,String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,double basicSalary,double epf, double companyPf,int accountNumber, 
			String bankName, String ifscCode)throws AssociateDetailsNotFound,PayrollServicesDownException;
}