package com.cg.banking.beans;

public class Customer {
	private  String customerId,firstName,lastName,emailId,pancardNo,
	dateOfBirth;
	private long mobileNo,adharNo;
	private Account []accounts;
	private Address localaddress,homeaddress;
	public Customer() {}
	public Customer(String customerId, String firstName, String lastName, String emailId, String pancardNo,
			String dateOfBirth, long mobileNo, long adharNo, Account[] accounts, Address localaddress,
			Address homeaddress) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.accounts = accounts;
		this.localaddress = localaddress;
		this.homeaddress = homeaddress;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public long getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}
	public Account[] getAccounts() {
		return accounts;
	}
	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}
	public Address getLocaladdress() {
		return localaddress;
	}
	public void setLocaladdress(Address localaddress) {
		this.localaddress = localaddress;
	}
	public Address getHomeaddress() {
		return homeaddress;
	}
	public void setHomeaddress(Address homeaddress) {
		this.homeaddress = homeaddress;
	}
	
}
