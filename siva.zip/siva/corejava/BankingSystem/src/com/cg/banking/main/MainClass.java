package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Customer customer=new Customer("hdfc123","siva","prasad","siva@gamil.com","bckpt2323r","10/11/1995",9999999999L,12345678945L,new Account[1],new Address("pune","MAharastra","40404","India"),new Address("hyd","telangana","07404","india"));
		System.out.println(customer.getHomeaddress().getCity());
		
	}
}
