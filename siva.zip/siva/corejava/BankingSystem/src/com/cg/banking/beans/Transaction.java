package com.cg.banking.beans;

public class Transaction {
	private  String transactionId,timeStamp,transactionType,transactionLocation,modeOfTransation,transactionStatus;	
	private String ammount;
	public Transaction() {}
	public Transaction(String transactionId, String timeStamp, String transactionType, String transactionLocation,
			String modeOfTransation, String transactionStatus, String ammount) {
		super();
		this.transactionId = transactionId;
		this.timeStamp = timeStamp;
		this.transactionType = transactionType;
		this.transactionLocation = transactionLocation;
		this.modeOfTransation = modeOfTransation;
		this.transactionStatus = transactionStatus;
		this.ammount = ammount;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionLocation() {
		return transactionLocation;
	}
	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}
	public String getModeOfTransation() {
		return modeOfTransation;
	}
	public void setModeOfTransation(String modeOfTransation) {
		this.modeOfTransation = modeOfTransation;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getAmmount() {
		return ammount;
	}
	public void setAmmount(String ammount) {
		this.ammount = ammount;
	}
	
}
