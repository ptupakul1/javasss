package com.cg.banking.beans;

public class Account {
	private  int accountNo,accountBalance ;
	private String accountType;
	private Transaction []trancations;
	public Account() {}
	public Account(int accountNo, int accountBalance, String accountType, Transaction[] trancations) {
		super();
		this.accountNo = accountNo;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.trancations = trancations;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Transaction[] getTrancations() {
		return trancations;
	}
	public void setTrancations(Transaction[] trancations) {
		this.trancations = trancations;
	}
	
	
}
