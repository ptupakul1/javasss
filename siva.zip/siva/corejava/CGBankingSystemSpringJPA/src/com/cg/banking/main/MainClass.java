package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		try {
			ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
			BankingServices bankingServices=(BankingServices) applicationContext.getBean("bankingServices");

//			System.out.println(bankingServices.acceptCustomerDetails("ds", "sd", "sds", "asd", "sd", "sd", 888, "sd", "sda", 56));
//			System.out.println(bankingServices.acceptCustomerDetails("ds", "sd", "sds", "asd", "sd", "sd", 888, "sd", "sda", 56));
//			System.out.println(bankingServices.acceptCustomerDetails("ds", "sd", "sds", "asd", "sd", "sd", 888, "sd", "sda", 56));
//			System.out.println(bankingServices.openAccount(1, "Savings", 500));
//			System.out.println(bankingServices.openAccount(1, "Savings", 500));
//			System.out.println(bankingServices.openAccount(2, "Savings", 500));
//			System.out.println(bankingServices.generateNewPin(1, 1));
//			System.out.println(bankingServices.depositAmount(1, 1, 500)); 
//			System.out.println(bankingServices.depositAmount(1, 2, 500));
//			System.out.println(bankingServices.getAllCustomerDetails());
			System.out.println(bankingServices.changeAccountPin(1, 1, 7777, 7789));
			//System.out.println(bankingServices.accountStatus(1, 1));
			//System.out.println(bankingServices.withdrawAmount(1, 1, 200, 15));
			//System.out.println(bankingServices.removecustomer(1));
			// System.out.println(bankingServices.generateNewPin(1, 1));
		} catch (BankingServicesDownException | CustomerNotFoundException | AccountNotFoundException | InvalidPinNumberException e) {
			e.printStackTrace();
		}



	}
}