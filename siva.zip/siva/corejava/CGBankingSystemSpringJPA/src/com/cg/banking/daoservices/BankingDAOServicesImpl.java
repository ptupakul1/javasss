package com.cg.banking.daoservices;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.QueryHint;
import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

@Component(value="bankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private EntityManagerFactory entityManagerFactory;
	private EntityManager e;
	@Override
	public int insertCustomer(Customer customer) {
		e=entityManagerFactory.createEntityManager();
		e.getTransaction().begin();
		e.persist(customer);
		e.flush();
		e.getTransaction().commit();
		e.close();
		return customer.getCustomerId();

	}

	@Override
	public long insertAccount(int customerId, Account account) {
		e=entityManagerFactory.createEntityManager();
		Customer customer=e.find(Customer.class, customerId);
		if(customer!=null){
			e.getTransaction().begin();
			e.persist(account);
			account.setStatus("Active");
			Transaction transaction=new Transaction(account.getAccountBalance(), "deposit");
			transaction.setAccount(account);
			e.persist(transaction);
			account.setCustomer(customer);
			e.flush();
			e.getTransaction().commit();
			e.close();
			return account.getAccountNo();
		}
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		e=entityManagerFactory.createEntityManager();
		Customer customer=e.find(Customer.class, customerId);
		if(customer!=null){
			e.getTransaction().begin();
			e.merge(account);
			e.flush();
			e.getTransaction().commit();
			e.close();
			return true;
		}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		e=entityManagerFactory.createEntityManager();
		int ran=(int) (int)(Math.random()*9000)+1000;
		e.getTransaction().begin();
		account.setPinNumber(ran);
		updateAccount(customerId, account);
		return ran;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		e=entityManagerFactory.createEntityManager();
		Account account=e.find(Account.class, accountNo);
		if(account!=null){
			e.getTransaction().begin();
			transaction.setAccount(account);
			e.persist(transaction);
			e.flush();
			e.getTransaction().commit();
			e.close();
			return true;}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		e=entityManagerFactory.createEntityManager();
		Customer customer=getCustomer(customerId);
		e.getTransaction().begin();
		e.remove(customer);
		e.flush();
		e.getTransaction().commit();
		e.close();
		return true;

	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		e=entityManagerFactory.createEntityManager();
		Account account=getAccount(customerId, accountNo);
		if(account!=null){
			e.getTransaction().begin();
			e.remove(account);
			e.flush();
			e.getTransaction().commit();
			e.close();
			return true;
		}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		e=entityManagerFactory.createEntityManager();
		return e.find(Customer.class, customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		e=entityManagerFactory.createEntityManager();
		if(e.find(Customer.class, customerId)!=null)
			return e.find(Account.class, accountNo);
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		e=entityManagerFactory.createEntityManager();
		TypedQuery<Customer>customers=e.createQuery("From Customer",Customer.class);
		return customers.getResultList();
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		
		e=entityManagerFactory.createEntityManager();
		TypedQuery<Account>accounts=e.createQuery("From Account where customer_customerId=?",Account.class);
		accounts.setParameter(1, customerId);
		return accounts.getResultList();
		
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		e=entityManagerFactory.createEntityManager();
		TypedQuery<Transaction>transactions=e.createQuery("From Transaction where account_accountNo=?",Transaction.class);
		transactions.setParameter(1, accountNo);
		return transactions.getResultList();
	}



}


