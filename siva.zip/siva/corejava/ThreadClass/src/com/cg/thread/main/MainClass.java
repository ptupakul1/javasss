package com.cg.thread.main;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import com.cg.thread.beans.Customer;
//import com.cg.thread.beans.MyThread;
//import com.cg.thread.beans.RunnableResource;

public class MainClass {

	public static void main(String[] args) throws IOException {
		/*MyThread t1=new MyThread("thread1");
		MyThread t2=new MyThread("thread2");
        t2.start();
        t1.start();
		RunnableResource res=new RunnableResource();
		Thread th1=new Thread(res,"thread1");
		Thread th2=new Thread(res,"thread2");
		th1.setPriority(10);
		th1.start();
	    th2.start();*/
		
		Thread th1=new Thread(new Customer(),"siva");
		Thread th2=new Thread(new Customer(),"prasad");
		Thread th3=new Thread(new Customer(),"surya");
		th1.start();
		th2.start();
		th3.start();
		
		
	}

}
