package com.cg.thread.beans;

public class Customer implements Runnable{
	private static Account account;
	public Customer(){}
	static{
		account =new Account(10000);
		System.out.println("InitialBalance    :-"+ account.getBalance());
		}
	@Override
	public void run() {

		Thread CustomerThread=Thread.currentThread();
		if(CustomerThread.getName().equals("prasad")){
			for(int i=1;i<=10;i++){
				try {
					Thread.sleep(100);
					System.out.println("prasad has call withdraw()"+ i +"time balance =" +account.withdraw(2000));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
		if(CustomerThread.getName().equals("siva")){
			for(int i=1;i<=10;i++){
				try {
					Thread.sleep(100);
					System.out.println("siva has call deposit()"+ i +"time balance =" +account.deposit(2000));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		if(CustomerThread.getName().equals("surya")){
			for(int i=1;i<=10;i++){
				try {
					Thread.sleep(100);
					System.out.println("surya has call check()"+ i +"time balance =" +account.getBalance());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
}
	}