package com.cg.thread.beans;

public class Account {
private static int SUCCESS,FAIL=0;
private volatile  int  balance;
public  Account() {
	
}
public Account(int balance) {
	super();
	this.balance = balance;
}
public static int getSUCCESS() {
	return SUCCESS;
}
public static void setSUCCESS(int sUCCESS) {
	SUCCESS = sUCCESS;
}
public static int getFAIL() {
	return FAIL;
}
public static void setFAIL(int fAIL) {
	FAIL = fAIL;
}
public int getBalance() {
	return balance;
}
public  void setBalance(int balance) {
	this.balance = balance;
}
@Override
public String toString() {
	return "Account [balance=" + balance + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + balance;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Account other = (Account) obj;
	if (balance != other.balance)
		return false;
	return true;
}
	public synchronized int deposit(int amount){
		balance=balance+amount;
		this.notify();
				return balance;
	}
	public synchronized int withdraw(int amount) throws InterruptedException{
		if(balance<0||getBalance()-amount<0){
			System.out.println("df");
			this.wait(5000);
			return balance;
		}
		else{
		balance=balance-amount;
				return balance;
		}	}
}
