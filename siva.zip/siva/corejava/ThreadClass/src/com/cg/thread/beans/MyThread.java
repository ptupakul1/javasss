package com.cg.thread.beans;

public class MyThread extends Thread {

	public MyThread() {
		super();

	}
	public MyThread(String name){
		super(name);	   
	}
	public void run(){
		if(this.getName().equals("thread1"))
			for (int i = 0; i < 50; i++)
				System.out.print((2*i)  +",\t");
		else if(this.getName().equals("thread2"))
			for (int j = 0; j < 50; j++) 
				System.out.print((2*j)+1 +",\t");


	}
}
