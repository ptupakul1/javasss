package com.cg.thread.beans;

public class RunnableResource implements Runnable {
	
	@Override
	public void run() {
		Thread t=Thread.currentThread();
		if(t.getName().equals("thread1"))
			for (int i = 0; i < 50; i++){
				//if(i%2==0)
				System.out.println((2*i) +"\t");}
		else if(t.getName().equals("thread2"))
			for (int j = 0; j < 50; j++) 
				System.out.println((2*j)+1 +"\t");


	
		
	}

}
