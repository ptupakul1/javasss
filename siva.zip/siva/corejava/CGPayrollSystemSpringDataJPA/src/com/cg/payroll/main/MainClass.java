package com.cg.payroll.main;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.hibernate.jpa.criteria.ParameterRegistry;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;

import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;

import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;
public class MainClass {

	public static void main(String[] args) {			
		try {
			ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
			PayrollServices payrollServices=(PayrollServices)applicationContext.getBean("payrollServices");

			System.out.println(payrollServices.acceptAssociateDetails("sss", "ds", "SD", "SD", "designation", "pancard", 7777, 555, 55, 3, 123456, "bankName", "ifscCode"));
			System.out.println(payrollServices.acceptAssociateDetails("sss", "ds", "SD", "SD", "designation", "pancard", 7777, 555, 55, 3, 123456, "bankName", "ifscCode"));
		    //System.out.println(payrollServices.deleteAssociate(1));
		       //System.out.println(payrollServices.updateAssociatedetails(1, "siva", "prasad", "df", "ece", "a4", "BCKPT#^#(", 6000, 6000, 45, 00, 123456, "HDFC", "hdfc123"));
		System.out.println(payrollServices.getAssociateDetails(1));
		System.out.println(payrollServices.getAllAssociatesDetails());
		} catch (PayrollServicesDownException | AssociateDetailsNotFound e) {
			e.printStackTrace();
		}
	}
}



