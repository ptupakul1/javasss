package com.cg.leavemanagemetystem.services;

public interface LeaveManagementService {
public void applyLeave();
public void leaveCancellation();

}
