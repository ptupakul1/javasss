package com.cg.leavemanagemetystem.beans;

public class Employee {
	private int empId;
	private String name;
	private Leaves leave;
	public Employee(int empId, String name, Leaves leave) {
		super();
		this.empId = empId;
		this.name = name;
		this.leave = leave;
	}
	public Employee() {
		super();
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Leaves getLeave() {
		return leave;
	}
	public void setLeave(Leaves leave) {
		this.leave = leave;
	}
	
}