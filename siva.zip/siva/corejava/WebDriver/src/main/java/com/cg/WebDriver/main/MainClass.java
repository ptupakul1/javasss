package com.cg.WebDriver.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\javacrosskilling\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.co.in");
		WebElement searchFiled=driver.findElements(By.id("lst-ib")).get(0);
		searchFiled.sendKeys("java.com");
		searchFiled.submit();
        WebElement image=driver.findElements(By.linkText("Images")).get(0);
        image.click();
        WebElement s=driver.findElements(By.cssSelector("a[class=rg_ic rg_i]")).get(0);
        s.click();
	    WebElement a=driver.findElements(By.tagName("img")).get(0);
	    a.click();
	
	}

}
