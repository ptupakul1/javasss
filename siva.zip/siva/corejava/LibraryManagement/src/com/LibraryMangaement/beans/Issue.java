package com.LibraryMangaement.beans;

public class Issue {
		private String issueFromDate,issueToDate,bookIssueStatus,issuedBookID;
		private int issueDuration;
		
		public Issue(String issueFromDate, String issueToDate,
				String bookIssueStatus, String issuedBookID, int issueDuration) {
			super();
			this.issueFromDate = issueFromDate;
			this.issueToDate = issueToDate;
			this.bookIssueStatus = bookIssueStatus;
			this.issuedBookID = issuedBookID;
			this.issueDuration = issueDuration;
		}
		public String getIssueFromDate() {
			return issueFromDate;
		}
		public void setIssueFromDate(String issueFromDate) {
			this.issueFromDate = issueFromDate;
		}
		public String getIssueToDate() {
			return issueToDate;
		}
		public void setIssueToDate(String issueToDate) {
			this.issueToDate = issueToDate;
		}
		public String getBookIssueStatus() {
			return bookIssueStatus;
		}
		public void setBookIssueStatus(String bookIssueStatus) {
			this.bookIssueStatus = bookIssueStatus;
		}
		public String getIssuedBookID() {
			return issuedBookID;
		}
		public void setIssuedBookID(String issuedBookID) {
			this.issuedBookID = issuedBookID;
		}
		public int getIssueDuration() {
			return issueDuration;
		}
		public void setIssueDuration(int issueDuration) {
			this.issueDuration = issueDuration;
		}
		
}
