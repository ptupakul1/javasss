package com.LibraryMangaement.beans;

public class Return {
		private String dateOfReturn,returnStatus,returnedBookID;
		
		public Return(String dateOfReturn, String returnStatus,
				String returnedBookID) {
			super();
			this.dateOfReturn = dateOfReturn;
			this.returnStatus = returnStatus;
			this.returnedBookID = returnedBookID;
		}
		public String getDateOfReturn() {
			return dateOfReturn;
		}
		public void setDateOfReturn(String dateOfReturn) {
			this.dateOfReturn = dateOfReturn;
		}
		public String getReturnStatus() {
			return returnStatus;
		}
		public void setReturnStatus(String returnStatus) {
			this.returnStatus = returnStatus;
		}
		public String getReturnedBookID() {
			return returnedBookID;
		}
		public void setReturnedBookID(String returnedBookID) {
			this.returnedBookID = returnedBookID;
		}
		
}
