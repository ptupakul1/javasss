package com.cg.LoginTest.beans;

import java.sql.Driver;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class LoginTestPage {
 static WebDriver webDriver;
 LoginPage loginPage;
 @BeforeClass
 public static void setUpMockData(){
	 System.setProperty("webdriver.chrome.driver", "D:\\javacrosskilling\\chromedriver.exe");
      webDriver=new ChromeDriver();
      webDriver.manage().window().maximize();
 }
@AfterClass
 public static void tearDownMockdata(){
	 webDriver=null;
 }
 @Before
 public void before(){
	 webDriver.get("https://github.com/login");
	 loginPage=new LoginPage();
	 PageFactory.initElements(webDriver, loginPage);
 }
 @After
 public void after(){
	
	 webDriver.get("https://github.com/login");
	 loginPage=new LoginPage();
	 
 }
 @Test
 public void userNamepasswordEmpty(){
	 loginPage.setUsername("");
	 loginPage.setPassword("");
	 loginPage.clickSubmitButton();
	 String actualError=webDriver.findElement(By.xpath("//div[@class='container']")).getText();
     String expectedError="Incorrect username or password.";
     Assert.assertEquals(expectedError, actualError);
 }
 @Test
 public void userNameEmptypassword(){
	 loginPage.setUsername("");
	 loginPage.setPassword("siva@11234");
	 loginPage.clickSubmitButton();
	 String actualError=webDriver.findElement(By.xpath("//div[@class='container']")).getText();
     String expectedError="Incorrect username or password.";
     Assert.assertEquals(expectedError, actualError);
 }
 @Test
 public void passwordEmpty(){
	 loginPage.setUsername("siva@11234");
	 loginPage.setPassword("");
	 loginPage.clickSubmitButton();
	 String actualError=webDriver.findElement(By.xpath("//div[@class='container']")).getText();
     String expectedError="Incorrect username or password.";
     Assert.assertEquals(expectedError, actualError);
 }
 @Test
 public void userNamepassword(){
	 loginPage.setUsername("ptupakul1");
	 loginPage.setPassword("prasad@208");
	 loginPage.clickSubmitButton();
	 String actual=webDriver.findElement(By.tagName("strong[@class='css-truncate-target']")).getText();
     String expected="ptupakul1";
     Assert.assertEquals(expected, actual);
 }
}
