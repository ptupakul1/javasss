package com.cg.exceptionhandling.main;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		try {
			Scanner scr=new Scanner(System.in);
			System.out.println("enter 1st number:");
			int a=scr.nextInt();
			System.out.println("enter 2nd number:");
			int b=scr.nextInt();
			System.out.println(a/b);
			
		} catch (Exception e) {
		e.printStackTrace();	
		}
		

	}

}
