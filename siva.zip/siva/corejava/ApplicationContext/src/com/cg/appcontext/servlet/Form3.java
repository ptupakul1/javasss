package com.cg.appcontext.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appcontext.beans.UserDetails;


@WebServlet("/Form3")
public class Form3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init() {}

	public void destroy() {

	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter wr=response.getWriter();
		
		String city =request.getParameter("city");
		String state=request.getParameter("state");	
		ServletContext context = getServletContext();
		 UserDetails user=(UserDetails)context.getAttribute("userDetails");	
	
		
		wr.print("<html>");
		wr.println("<body>");
		wr.println("<div align='center'>");
		wr.println("<form name='f3'method='post'action='Form4'>");
		wr.println("<table>");
		wr.println("<tr>");
		wr.println("<td> firstName:</td><td>"+user.getFirstName()+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>lastName:</td><td>"+user.getLastName()+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>city:</td><td>"+city+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>state:</td><td>"+state+"</td></tr>");
		wr.println("<tr>");
        wr.println("<td> Enter EmailID:</td>");
        wr.println("<td><input type='email'name='email'></td>");
        wr.println("</tr>");
        wr.println("<tr>");
        wr.println("<td> Enter PhoneNo:</td>");
        wr.println("<td><input type='phone'name='phoneNo'></td>");
        wr.println("</tr>");
        wr.println("<tr align ='center'>");
        wr.println("<td><input type='submit'></td>");
        wr.println("</tr>");
		wr.println("</table>");
		wr.println("</form>");
		wr.println("</div>");
		wr.println("</body>");
		wr.println("</html>");
		UserDetails userDetails=new UserDetails(user.getFirstName(), user.getLastName(),city,state);
		context.setAttribute("userDetails", userDetails);

	}
	

}
