package com.cg.hiddenfields.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;






@WebServlet("/Page4")
public class Page4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init()  {
	}


	public void destroy() {
	}


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter wr=response.getWriter();
		String email =request.getParameter("email");
		String phoneNo=request.getParameter("phoneNo");	
		String firstName=request.getParameter("firstName");	
		String lastName=request.getParameter("lastName");	
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		wr.print("<html>");
		wr.println("<body>");
		wr.println("<div align='center'>");
		wr.println("<table>");
		wr.println("<tr>");
		wr.println("<td>FirstName:</td><td>"+firstName+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>lastName:</td><td>"+lastName+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>city:</td><td>"+city+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>state:</td><td>"+state+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>email:</td><td>"+ email+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>phoneNO:</td><td>"+  phoneNo+"</td>");
		wr.println("</tr>");
		wr.println("</table>");
		wr.println("</div>");
		wr.println("</body>");
		wr.println("</html>");
	}

}
