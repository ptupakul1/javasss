package com.cg.hiddenfields.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Page1
 */
@WebServlet("/Page1")
public class Page1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	} 
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
        writer.println("<html>");
        writer.println("<body>");
        writer.println("<div align='center'>");
        writer.println("<form action='Page2' method='post' name='form1'>");
        writer.println("<table>");
        writer.println("<tr><td>Enter FirstName:</td><td><input type='text'name='firstName'></td>");
        writer.println("<tr><td>Enter lastName:</td><td><input type='text'name='lastName'></td>");
        writer.println("<tr><td><input type='submit'name='submit'></td>");
        writer.println("</table>");
        writer.println("</form>");
        writer.println("</div >");
        writer.println("</body>");
        writer.println("<html>");
	}
	
}
