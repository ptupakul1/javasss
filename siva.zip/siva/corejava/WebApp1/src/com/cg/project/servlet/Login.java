package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.spi.DirStateFactory.Result;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.UserDetails;
@WebServlet(value={"/Login"},loadOnStartup=1)
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;

	public void init(){
		ServletContext servletContext=getServletContext();
		con =(Connection) servletContext.getAttribute("con");
	}
	public void destroy() {}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/*	if(password.equals("Hello")&&userID.equals("Sivaprasad")){
			dispatcher=request.getRequestDispatcher("SuccessServlet");
			request.setAttribute("userDetails", userDetails);
			dispatcher.forward(request, response);
		}
		else
			dispatcher=request.getRequestDispatcher("Error");
		request.setAttribute("error"," Incorrect Details");
		dispatcher.forward(request, response);*/
		try {
			
			String userID=request.getParameter("userID");
			String password=request.getParameter("password");
			RequestDispatcher dispatcher;
			UserDetails userDetails=new UserDetails(userID, password);
			PreparedStatement	prt = con.prepareStatement("select password from registrationdetails where userID=?");
			prt.setString(1, userID);
			ResultSet r=prt.executeQuery();
			if(r.next()){
				if(password.equals(r.getString("password"))){
					dispatcher=request.getRequestDispatcher("Success.jsp");
					request.setAttribute("userDetails", userDetails);
					dispatcher.forward(request, response);}
				else{
					dispatcher=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("error"," Incorrect Details");
					dispatcher.forward(request, response);   }
			}
			else {
				dispatcher=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("error"," User not found");
				dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
