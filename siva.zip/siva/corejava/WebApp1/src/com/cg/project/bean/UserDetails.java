package com.cg.project.bean;

import java.util.List;

public class UserDetails {
 private String firstName,lastName,dateOfBirth,gender,email,phoneNO,userID,password,graduationDetails;
 private List<String> communication;
public UserDetails(String firstName, String lastName, String dateOfBirth, String gender, String email, String phoneNO,
		String userID, String password, List<String> communication,String graduationDetails) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.gender = gender;
	this.email = email;
	this.phoneNO = phoneNO;
	this.userID = userID;
	this.password = password;
	this.communication = communication;
	this.graduationDetails = graduationDetails;
}


public UserDetails(String userID, String password) {
	super();
	this.userID = userID;
	this.password = password;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(String dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneNO() {
	return phoneNO;
}
public void setPhoneNO(String phoneNO) {
	this.phoneNO = phoneNO;
}
public String getUserID() {
	return userID;
}
public void setUserID(String userID) {
	this.userID = userID;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public List<String> getCommunication() {
	return communication;
}
public void setCommunication(List<String> communication) {
	this.communication = communication;
}

public String getGraduationDetails() {
	return graduationDetails;
}


public void setGraduationDetails(String graduationDetails) {
	this.graduationDetails = graduationDetails;
}


@Override
public String toString() {
	return "UserDetails [firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth
			+ ", gender=" + gender + ", email=" + email + ", phoneNO=" + phoneNO + ", userID=" + userID + ", password="
			+ password + ", graduationDetails=" + graduationDetails + ", communication=" + communication + "]";
}


@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((communication == null) ? 0 : communication.hashCode());
	result = prime * result + ((dateOfBirth == null) ? 0 : dateOfBirth.hashCode());
	result = prime * result + ((email == null) ? 0 : email.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((gender == null) ? 0 : gender.hashCode());
	result = prime * result + ((graduationDetails == null) ? 0 : graduationDetails.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	result = prime * result + ((phoneNO == null) ? 0 : phoneNO.hashCode());
	result = prime * result + ((userID == null) ? 0 : userID.hashCode());
	return result;
}


@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	UserDetails other = (UserDetails) obj;
	if (communication == null) {
		if (other.communication != null)
			return false;
	} else if (!communication.equals(other.communication))
		return false;
	if (dateOfBirth == null) {
		if (other.dateOfBirth != null)
			return false;
	} else if (!dateOfBirth.equals(other.dateOfBirth))
		return false;
	if (email == null) {
		if (other.email != null)
			return false;
	} else if (!email.equals(other.email))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (gender == null) {
		if (other.gender != null)
			return false;
	} else if (!gender.equals(other.gender))
		return false;
	if (graduationDetails == null) {
		if (other.graduationDetails != null)
			return false;
	} else if (!graduationDetails.equals(other.graduationDetails))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	if (phoneNO == null) {
		if (other.phoneNO != null)
			return false;
	} else if (!phoneNO.equals(other.phoneNO))
		return false;
	if (userID == null) {
		if (other.userID != null)
			return false;
	} else if (!userID.equals(other.userID))
		return false;
	return true;
}



}
