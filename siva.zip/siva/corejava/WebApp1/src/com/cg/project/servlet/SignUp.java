package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.cg.project.bean.UserDetails;


@WebServlet("/SignUp")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;

	public void init(){
		ServletContext servletContext=getServletContext();
		con =(Connection) servletContext.getAttribute("con");
	}
	public void destroy() {}




	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			con.setAutoCommit(false);
			String firstName=request.getParameter("firstName");
			String lastName=request.getParameter("lastName");
			String dateOfBirth = request.getParameter("dateOfBirth");
			String gender=request.getParameter("gender");
			String email=request.getParameter("email");
			String phoneNO=request.getParameter("phoneNO");
			String userID=request.getParameter("userID");
			String password=request.getParameter("password");
			String repassword=request.getParameter("repassword");
			List <String>communication= Arrays. asList(request.getParameterValues("communication"));
			String graduationDetails=request.getParameter("graduationDetails");
			//String ste= request.getParameter("file");
			RequestDispatcher dispatcher;
			UserDetails userDetails=new UserDetails(firstName, lastName, dateOfBirth, gender, email, phoneNO, userID, password, communication, graduationDetails);
			if(password.equals(repassword)){ 
				PreparedStatement pre=con.prepareStatement("Insert into registrationdetails(firstName,lastName,dateOfBirth,gender,email,phoneNo,userID,password,graduationDetails)values(?,?,?,?,?,?,?,?,?)");
				pre.setString(1, firstName);
				pre.setString(2, lastName);
				pre.setString(3, dateOfBirth);
				pre.setString(4, gender);
				pre.setString(5, email);
				pre.setString(6, phoneNO);
				pre.setString(7, userID);
				pre.setString(8, password);
				pre.setString(9, graduationDetails);
				pre.executeUpdate();
				con.commit();
				System.out.println(7);
				dispatcher=request.getRequestDispatcher("Success.jsp");
				request.setAttribute("userDetails", userDetails);
				dispatcher.forward(request, response);
			}
			else{
				dispatcher=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("error", "password worng");
				dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}


	}


}
