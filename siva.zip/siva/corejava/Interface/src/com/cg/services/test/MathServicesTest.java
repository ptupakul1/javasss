package com.cg.services.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.services.beans.MathServices;
import com.cg.services.beans.MathServicesImpl;
import com.cg.services.exception.InvalidNoRangeException;




public class MathServicesTest {
private static MathServices services;
private int validnum1,validnum2,invalidnum1,invalidnum2;
 @BeforeClass
 public static void setUpTestEnv(){
	 services =new MathServicesImpl();
	 
	 
 }
 @Before
 public void setUpMockData(){
	 validnum1=10;
	 validnum2=20;
	 invalidnum1=-11;
	 invalidnum2=-88;
 }
 @Test(expected=InvalidNoRangeException.class)
 public void addTestFirstInvalidNo() throws InvalidNoRangeException{
	services.add(invalidnum1, validnum2);
	
 }
 @Test(expected=InvalidNoRangeException.class)
 public void addTestSecondInvalidNo() throws InvalidNoRangeException{
	services.add(validnum1, invalidnum2);
	
 }

@Test
 public void addTest() throws InvalidNoRangeException{
	Assert.assertEquals(30, services.add(validnum1, validnum2));
	
 }
@Test(expected=InvalidNoRangeException.class)
public void subTestFirstInvalidNo() throws InvalidNoRangeException{
	services.sub(invalidnum1, validnum2);
	}
@Test(expected=InvalidNoRangeException.class)
public void subTestSecondInvalidNo() throws InvalidNoRangeException{
	services.sub(invalidnum1, validnum2);
	}
@Test
public void subTest() throws InvalidNoRangeException{
	Assert.assertEquals(-10, services.sub(validnum1, validnum2));
	}
@Test(expected=InvalidNoRangeException.class)
public void divTestFirstInvalidNo() throws InvalidNoRangeException{
	services.div(invalidnum1, validnum2);
	}
@Test(expected=InvalidNoRangeException.class)
public void divTestSecondInvalidNo() throws InvalidNoRangeException{
	services.div(invalidnum1, validnum2);
	}
@Test
public void divTest() throws InvalidNoRangeException{
	Assert.assertEquals(0, services.div(validnum1, validnum2));
	}
 @After
 public void tearDownMockData(){
	 validnum1=10;
	 validnum2=20;
	 invalidnum1=-11;
	 invalidnum2=-88;
 }
 @AfterClass
 public static void tearDownEnv(){
	 services=null;
 }
	

}
