package com.cg.services.beans;

import com.cg.services.exception.InvalidNoRangeException;

public class MathServicesImpl implements MathServices {

	@Override
	public int add(int a, int b) throws InvalidNoRangeException {
		if(a<0)
			throw new InvalidNoRangeException("Enter 1st Number correctly");
		 if(b<0)
			throw new InvalidNoRangeException("Enter 2nd Number correctly");
	return a+b;
	}

	@Override
	public int div(int a, int b) throws InvalidNoRangeException {
		if(a<0)
			throw new InvalidNoRangeException("Enter 1st Number correctly");
		 if(b<0)
			throw new InvalidNoRangeException("Enter 2nd Number correctly");
	return a/b;
	}

	@Override
	public  int sub(int a, int b) throws InvalidNoRangeException {
		if(a<0)
			throw new InvalidNoRangeException("Enter 1st Number correctly");
		else if(b<0)
			throw new InvalidNoRangeException("Enter 2nd Number correctly");
	return a-b;
	}

	
}
