package com.cg.services.beans;

import com.cg.services.exception.InvalidNoRangeException;

public interface MathServices  {
 public abstract int add(int a,int b)throws InvalidNoRangeException;
 public int div(int a,int b)throws InvalidNoRangeException;;
 int sub(int a,int b)throws InvalidNoRangeException;;
}
