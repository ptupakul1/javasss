package com.cg.project.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.beans.Associate;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
        Associate associate=(Associate) applicationContext.getBean("associate");
        Associate associate1=(Associate) applicationContext.getBean("associate");
	   associate.setFirstName("sdasd");
	   
	   System.out.println(associate);
     /*   if(associate==associate1)
		   System.out.println("same reffee");
	   else
		   System.out.println("not same reff");
	   if(associate.equals(associate1))
		   System.out.println("same data");
	   else
		   System.out.println("not data");*/
	}

}
