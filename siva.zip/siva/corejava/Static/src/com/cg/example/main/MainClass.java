package com.cg.example.main;
import  com.cg.example.bean.Number;
 
public class MainClass {

	public static void main(String[] args) {
       Number number=new Number();
       System.out.println(Number.NUMBER);
       System.out.println(number.NUMBER);
	}

}
