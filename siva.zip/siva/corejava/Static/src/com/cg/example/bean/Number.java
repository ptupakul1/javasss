package com.cg.example.bean;

public class Number {
    private int Num;
    public static String NUMBER;
    public Number(){}
}
