package com.cg.eventmanagement.main;

import com.cg.eventmanagement.beans.Catering;
import com.cg.eventmanagement.beans.Customer;
import com.cg.eventmanagement.beans.Event;
import com.cg.eventmanagement.beans.EventAddress;
import com.cg.eventmanagement.beans.Menu;

public class MainClass {

	public static void main(String[] args) {
	Event event[]=new Event[2];
	Menu menu[] =new Menu[2];
	event[0]=new Event("abcd","10-11-2018","10-12-2018",400000,32,500,new Customer("siva",9000000L),new EventAddress("pune","MAHARASTRA","india",44141414),new Catering("dd","self",40000,menu));
	

	}

}
