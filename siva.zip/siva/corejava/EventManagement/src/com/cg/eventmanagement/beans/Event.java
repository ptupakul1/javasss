package com.cg.eventmanagement.beans;

public class Event {
	private String typeofEvent,eventFromDate,eventToDate;
	private int eventCost,noofDays,noofAttendies;
	private Customer customer;
	private EventAddress eventaddress;
	private Catering catering;
	public Event() {}
	public Event(String typeofEvent, String eventFromDate, String eventToDate, int eventCost, int noofDays,
			int noofAttendies, Customer customer, EventAddress eventaddress, Catering catering) {
		super();
		this.typeofEvent = typeofEvent;
		this.eventFromDate = eventFromDate;
		this.eventToDate = eventToDate;
		this.eventCost = eventCost;
		this.noofDays = noofDays;
		this.noofAttendies = noofAttendies;
		this.customer = customer;
		this.eventaddress = eventaddress;
		this.catering = catering;
	}
	public String getTypeofEvent() {
		return typeofEvent;
	}
	public void setTypeofEvent(String typeofEvent) {
		this.typeofEvent = typeofEvent;
	}
	public String getEventFromDate() {
		return eventFromDate;
	}
	public void setEventFromDate(String eventFromDate) {
		this.eventFromDate = eventFromDate;
	}
	public String getEventToDate() {
		return eventToDate;
	}
	public void setEventToDate(String eventToDate) {
		this.eventToDate = eventToDate;
	}
	public int getEventCost() {
		return eventCost;
	}
	public void setEventCost(int eventCost) {
		this.eventCost = eventCost;
	}
	public int getNoofDays() {
		return noofDays;
	}
	public void setNoofDays(int noofDays) {
		this.noofDays = noofDays;
	}
	public int getNoofAttendies() {
		return noofAttendies;
	}
	public void setNoofAttendies(int noofAttendies) {
		this.noofAttendies = noofAttendies;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public EventAddress getEventaddress() {
		return eventaddress;
	}
	public void setEventaddress(EventAddress eventaddress) {
		this.eventaddress = eventaddress;
	}
	public Catering getCatering() {
		return catering;
	}
	public void setCatering(Catering catering) {
		this.catering = catering;
	}
	
}
