package com.cg.payroll.serial;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class Serialization {
	/*public static void doserialization(File file) throws IOException{
		if(PayrollDAOServicesImpl.associatelist.size()==0)
			return ;
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
			dest.writeObject(PayrollDAOServicesImpl.associatelist);	

		}
	}
	public static void doDeserialization(File file) throws IOException, ClassNotFoundException{
		if(file.length()==0)
			return;
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(file))){
			PayrollDAOServicesImpl.associatelist= (HashMap<Integer, Associate>) src.readObject();	
            PayrollUtility.ASSOCIATE_ID_COUNTER=Collections.max(PayrollDAOServicesImpl.associatelist.keySet())+1;

		}
	}*/
}