package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.hibernate.Transaction;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
import com.mysql.jdbc.PreparedStatement;

@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private SessionFactory sessionFactory;
	private Transaction tran=null;
   // private Session session=sessionFactory.openSession();
	public PayrollDAOServicesImpl() {
		super();
	}


	//public PayrollDAOServicesImpl(SessionFactory sessionFactory) {
	//	this.sessionFactory=sessionFactory;
	//}


	@Override
	public int insertAssociate(Associate associate) throws SQLException {

		return (int) sessionFactory.openSession().save(associate);
	}


	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		Session session=sessionFactory.openSession();
		if(getAssociate(associate.getAssociateID())!=null){
		      tran=session.beginTransaction();
        	session.update(associate);
        	tran.commit();
		return true;}
        return false;
	}


	@Override
	public boolean deleteAssociate(int associateID) throws SQLException {
		try {
			Session session=sessionFactory.openSession();
			Associate associate=getAssociate(associateID);
			if(associate!=null){
				tran= session.beginTransaction();
				session.delete(associate);
				tran.commit(); 
				return true;
			}
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		return false;

	}
	@Override
	public Associate getAssociate(int associateID) throws SQLException {
		return (Associate) sessionFactory.openSession().get(Associate.class, associateID);
	}


	@Override
	public List<Associate> getAssociates()  {
		List<Associate> associates =sessionFactory.openSession().createQuery("from Associate").list();
		return associates;
	}





}
