package com.cg.payroll.main;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.serial.Serialization;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;
public class MainClass {

	public static void main(String[] args) {			
		try {
		ApplicationContext applicationContext= new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices) applicationContext.getBean("payrollServices");
		
			System.out.println(payrollServices.acceptAssociateDetails("siava", "prasad", "emailId", "department", "designation", "pancard", 44444, 4, 4, 4, 4, "bankName", "ifscCode"));
		System.out.println(payrollServices.updateAssociatedetails(1, "srrrrrrrrrra", "prasad", "sdf", "dsf", "designation", "pancard", 2222, 888, 994, 9999, 966, "bankName", "ifscCode"));
		//System.out.println(payrollServices.deleteAssociate(1));
		//System.out.println(payrollServices.getAllAssociatesDetails());
		} catch (PayrollServicesDownException | AssociateDetailsNotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}



