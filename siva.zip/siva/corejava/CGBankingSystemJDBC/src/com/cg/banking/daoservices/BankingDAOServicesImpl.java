package com.cg.banking.daoservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

@Component(value="bankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
    @Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	public int insertCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}
	
	}


