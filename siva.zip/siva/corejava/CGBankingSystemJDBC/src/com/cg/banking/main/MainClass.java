package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		 try {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
	      BankingServices bankingServices=(BankingServices) applicationContext.getBean("bankingServices");
	     
			bankingServices.getAllCustomerDetails();
		} catch (BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}