package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;

public interface PayrollServices {

	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
			int accountNumber, String bankName, String ifscCode);

	int calaculateNetSalary(int associateID)throws AssociateDetailsNotFound;

	Associate getAssociateDetails(int associateID)throws AssociateDetailsNotFound;

	Associate[] getAllAssociatesDetails();
    boolean deleteAssociate(int associateId)throws AssociateDetailsNotFound;
    boolean updateAssociate(Associate associate)throws AssociateDetailsNotFound;
}