package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;

public class PayrollServicesImpl implements PayrollServices {
	private PayrollDAOServices daoServices;
	public PayrollServicesImpl() {
		daoServices=new PayrollDAOServicesImpl();
	}

	public int acceptAssociateDetails( String firstName, String lastName,String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,double basicSalary,double epf, double companyPf,int accountNumber, 
			String bankName, String ifscCode){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard,emailId,new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}

	public int calaculateNetSalary(int associateID)throws AssociateDetailsNotFound{
		Associate associate=this.getAssociateDetails(associateID);
		associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary()*0.3);
		associate.getSalary().setConveyenceAllowance(associate.getSalary().getBasicSalary()*0.2);
		associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary()*0.1);
		associate.getSalary().setHra(associate.getSalary().getBasicSalary()*0.25);
		associate.getSalary().setGratuity(associate.getSalary().getBasicSalary()*0.05);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		double annualSalary=associate.getSalary().getGrossSalary()*12;
		double unTaxable=associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
		double taxable,tax=0;
		if (unTaxable>150000){
			double taxable1=unTaxable-150000;
			taxable=annualSalary-150000+taxable1;
		}
		else	{
			taxable=annualSalary-unTaxable;
		}
		if (taxable>1000000){
			double taxable2=taxable-1000000;
			tax=tax+(taxable2*0.3f);
			taxable=taxable-taxable2;
		}
		if(taxable>500000&&taxable<=1000000){
			double taxable2=(taxable-500000);
			tax=tax+(taxable2*0.2f);
			taxable=taxable-taxable2;		}

		if(taxable>250000&&taxable<=500000){
			double taxable2=(taxable-250000);
			tax=tax+(taxable2*0.1f);
			taxable=taxable-taxable2;	
		}
		associate.getSalary().setMonthlyTax(tax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		return associateID;
		//return 0;
	}



	public Associate getAssociateDetails(int associateID)throws AssociateDetailsNotFound{
	Associate associate=daoServices.getAssociate(associateID);
	     if(associate==null)
	    	throw  new AssociateDetailsNotFound("notasassdss found");
		return associate;
	}

	public Associate[] getAllAssociatesDetails(){
		return null;
	}
	public boolean deleteAssociate(int associateId)throws AssociateDetailsNotFound{
		boolean a=daoServices.deleteAssociate(associateId);
		System.out.println(a);
		if(a==false)
			throw new AssociateDetailsNotFound("not sdfasdffound");
		return a;
	}
	public boolean updateAssociate(Associate associate)throws AssociateDetailsNotFound{
		boolean a=daoServices.updateAssociate(associate);
		if(a==false)
			throw new AssociateDetailsNotFound("not found");
		return a;
		
	}
}
