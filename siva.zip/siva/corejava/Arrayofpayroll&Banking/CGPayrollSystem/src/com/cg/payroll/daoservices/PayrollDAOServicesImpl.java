package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	private static Associate[] associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;

	public int insertAssociate(Associate associate){
		if(ASSOCIATE_IDX_COUNTER>(70/100)*(associateList.length)){
			Associate[] list=new Associate[associateList.length+20];
			for(int i=0;i<associateList.length;i++)
				list[i]=associateList[i];
			associateList=list;
		}
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID() ;
	}

	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null&&associateList[i].getAssociateID()==associate.getAssociateID()){
				associateList[i]=associate;
				return true;
			}
		return false;
	}

	public boolean deleteAssociate(int associateID){
		for(int k=0;k<associateList.length;k++)
			if(associateList[k]==null)
				for (int l = k+1; l < associateList.length; l++)
					if(associateList[l]!=null){
						associateList[k]=associateList[l];
						associateList[l]=null;
						System.out.println(ASSOCIATE_IDX_COUNTER);
						break;

					}
		for(int i=0;i<associateList.length;i++){
			if(associateList[i]!=null&&associateID==associateList[i].getAssociateID()){
				associateList[i]=null;
				ASSOCIATE_IDX_COUNTER--;
				return true;
			} 

		}

		return false;
	}


	public Associate getAssociate(int associateID){
		for(int i=0;i<associateList.length;i++){
			if(associateList[i]!=null&&associateList[i].getAssociateID()==associateID)
				return associateList[i];
		}
		return null;
	}

	public Associate[] getAssociate(){
		return associateList;
	}
}


