package com.cg.banking.main;

import java.lang.reflect.Executable;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		try{
		/*BankingServicesImpl bankingservices=new BankingServicesImpl();
		BankingServicesImpl bankingservices2=new BankingServicesImpl();
		int customerID=bankingservices.acceptCustomerDetails("sd", "sd", "dffsf", "dfds", "sd", "localAddressState", 3333," homeAddressCity", "homeAddressState", 333);
		int customerID2=bankingservices2.acceptCustomerDetails("sd", "sd", "dffsf", "dfds", "sd", "localAddressState", 3333," homeAddressCity", "homeAddressState", 333);
		System.out.println(customerID);
	    Customer customer=bankingservices.getCustomerDetails(1111);
	    System.out.println(customer);
	    long a=bankingservices.openAccount(1111, "Savings", 500);
	    long b=bankingservices.openAccount(customerID2, "Savings", 500);
		//System.out.println(a);
		System.out.println(bankingservices.depositAmount(1111, 777, 500));
		System.out.println(bankingservices.generateNewPin(1111, 777));
		System.out.println(bankingservices.withdrawAmount(1111, 777, 200, 4562));
		System.out.println(bankingservices.fundTransfer(1112, 778, 1111, 777, 200, 4562));
		Account account=bankingservices.getAccountDetails(1111, 777);
		System.out.println(account.getPinCounter());
		Transaction transaction[]=bankingservices.getAccountAllTransaction(1111, 777);
		for (Transaction	transaction2	: transaction) {
			
			System.out.println(transaction2);
		}*/
			System.out.println("Choose any option:\n1. For New Customer\n2. For New Account\n3. For Withdraw Amount\n4. For Depoist Amount\n5. For Funds transfer\n6. For Details of coustomer");
			System.out.println("7. For Account Details\n8. For generate New Pin\n9.change Account Pin\n10.AllCustomerDetails\n11.customerAllAccountDetails\n12. AccountAllTransaction\n13.accountStatus\n14.closeAccount");
			Scanner scr=new Scanner(System.in);
			int i= scr.nextInt();
			switch (i) {
			case 1:
				
				
				break;

			default:
				break;
			}
					
			
		}
		
	 catch(Exception e) {
			//e.printStackTrace();
			System.out.println(e);

	}
}
}