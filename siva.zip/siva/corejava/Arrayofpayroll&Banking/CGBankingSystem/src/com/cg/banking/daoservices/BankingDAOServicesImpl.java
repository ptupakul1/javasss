package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	private static Customer customerlist[]=new Customer[10];
	private static int CUSTOMER_ID_COUNTER=1111;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static int ACCOUNT_ID_COUNTER=777;
	private static int TRANSACTION_ID=52336;
	private static int pinnumber=1001;
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerlist[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();

	}

	@Override
	public long insertAccount(int customerId, Account account) {
		for(int i=0;i<customerlist.length;i++)
			if(customerlist[i]!=null&&customerId==customerlist[i].getCustomerId()){
				int j=customerlist[i].getAccountidxcounter();
				account.setAccountNo(ACCOUNT_ID_COUNTER++);
				customerlist[i].getAccounts()[customerlist[i].getAccountidxcounter()]=account;
				customerlist[i].setAccountIdxcounter(customerlist[i].getAccountidxcounter()+1);
				return account.getAccountNo();
			}
		return 0;
	}


	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerlist.length;i++)
			if(customerlist[i]!=null&&customerId==customerlist[i].getCustomerId()){
				for(int k=0;k<customerlist[i].getAccounts().length;k++)
					if(customerlist[i].getAccounts()[k]!=null&&customerlist[i].getAccounts()[k].getAccountNo()==account.getAccountNo()){
						customerlist[i].getAccounts()[k]=account;
						return true;
					}
			}
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		for(int i=0;i<customerlist.length;i++)
			if(customerId==customerlist[i].getCustomerId()){
				for(int k=0;k<customerlist[i].getAccounts().length;k++)
					if(customerlist[i].getAccounts()[k]!=null&&customerlist[i].getAccounts()[k].getAccountNo()==account.getAccountNo()){
						customerlist[i].getAccounts()[k].setPinNumber(pinnumber++);
						return  customerlist[i].getAccounts()[k].getPinNumber(); 
					}
			}
		return 0;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		Account account=this.getAccount(customerId, accountNo);
		if(account!=null){
			transaction.setTransactionId(TRANSACTION_ID++);
			account.getTransactions()[account.getTransactionidxcounter()]=transaction;
			account.setTransactionidxcounter(account.getTransactionidxcounter()+1);
			return true;
		} 
		return false;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerlist.length;i++)
			if(customerlist[i]!=null&&customerId==customerlist[i].getCustomerId()){
				customerlist[i]=null;
				//	CUSTOMER_IDX_COUNTER--;
				return true;
			}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<customerlist.length;i++)
			if(customerlist[i]!=null&&customerId==customerlist[i].getCustomerId()){
				for(int k=0;k<customerlist[i].getAccounts().length;k++)
					if(customerlist[i].getAccounts()[k]!=null&&customerlist[i].getAccounts()[k].getAccountNo()==accountNo){
						// int j=customerlist[i].getAccounts()
						customerlist[i].getAccounts()[k]=null;
						return true;
					}
			}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerlist.length;i++)
			if(customerlist[i]!=null&&customerId==customerlist[i].getCustomerId())
				return customerlist[i];

		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<customerlist.length;i++)
			if(customerlist[i]!=null&&customerId==customerlist[i].getCustomerId()){
				for(int k=0;k<customerlist[i].getAccounts().length;k++)
					if(customerlist[i].getAccounts()[k]!=null&&customerlist[i].getAccounts()[k].getAccountNo()==accountNo)
						return customerlist[i].getAccounts()[k];
			}
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		if(customerlist!=null)
			return customerlist;
		return null;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		Customer customer=getCustomer(customerId);
		if(customer!=null)
			return customer.getAccounts();
		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		Account account=getAccount(customerId, accountNo);
		if(account!=null)
			return account.getTransactions();
		return null;

	}

}
