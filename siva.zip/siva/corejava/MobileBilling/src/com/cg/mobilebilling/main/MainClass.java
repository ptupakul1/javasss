package com.cg.mobilebilling.main;
import com.cg.mobilebilling.beans.*;

public class MainClass {

	public static void main(String[] args) {
		Customer []customer=new Customer[3];
		customer[0] =new Customer("kk123","sai","prasad","sai@gamil.com","phbfs45","11/03/1996",123456789788L,12345677789L,new PostPAidAccount[2],new Address("pune","MAharastra","04044","India"));
		PostPAidAccount []postpaidaccounts=customer[0].getPostpaidaccounts();
		postpaidaccounts[0]=new PostPAidAccount(98755, new Plan(), new Bill[3]);
		System.out.println(postpaidaccounts[0].getMobileNo());
		System.out.println(postpaidaccounts[0].getPlan().getFreeLocalCalls());
		
	}

}
