package com.cg.payroll.test;






import static org.junit.Assert.*;

//import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {
 private static PayrollServices payrollservices;
 
 @BeforeClass
 public static void setUpTestEnv(){
	 payrollservices=new PayrollServicesImpl();
	 }
 @AfterClass
 public static void tearDownTestEnv(){
	 payrollservices=null;
 }
 @Before
 public void setUpMockData(){
	  Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 150000,"siva","prasad", "department", "designation"," pancard"," emailId@email", new Salary(15000, 52, 52), new	BankDetails(1234,"HDFC","HDFC777")); 
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 180000,"ravi","prasad", "department", "designation"," pancard"," siva@email", new Salary(18000,42, 72), new	BankDetails(1278,"HDFC","HDFC5555")); 
	    PayrollDAOServicesImpl.associatelist.put(associate1.getAssociateID(), associate1);
	    PayrollDAOServicesImpl.associatelist.put(associate2.getAssociateID(), associate2);

 }
 @After
 public void tearDownMockData(){
	 payrollservices.getAllAssociatesDetails().clear();
	 PayrollUtility.ASSOCIATE_ID_COUNTER=111;
 }
 @Test
 public void acceptAssocaiteDetailsForvalidData(){
	assertEquals(113,payrollservices.acceptAssociateDetails("siva","df","sss","df","d","d0",1456,15555,4,5,555555,"HDFC","HDFC111"));
 }
 @Test
 public void testAssociateDetails() throws AssociateDetailsNotFound{
	 Associate associate1=new Associate(111, 150000,"siva","prasad", "department", "designation"," pancard"," emailId@email", new Salary(15000, 52, 52), new	BankDetails(1234,"HDFC","HDFC777")); 
     assertEquals(associate1, payrollservices.getAssociateDetails(111));
	 
 }
 @Test(expected=AssociateDetailsNotFound.class)
 public void testAssociateDetails1() throws AssociateDetailsNotFound{
	 Associate associate1=new Associate(1111, 150000,"siva","prasad", "department", "designation"," pancard"," emailId@email", new Salary(15000, 52, 52), new	BankDetails(1234,"HDFC","HDFC777")); 
     assertEquals(associate1, payrollservices.getAssociateDetails(11));
	 
 }
 @Test
 public void testDeleteAssociate() throws AssociateDetailsNotFound{
	assertTrue(payrollservices.deleteAssociate(111));
	 
 }
 @Test(expected=AssociateDetailsNotFound.class)
 public void testDeleteAssociate1() throws AssociateDetailsNotFound{
	assertFalse(payrollservices.deleteAssociate(1111));
	 
 }
 @Test
 public void acceptAssocaiteDetailsForInvalidData(){
	Assert.assertNotEquals(144,payrollservices.acceptAssociateDetails("siva","df","sss","df","d","d0",1456,15555,4,5,555555,"HDFC","HDFC111"));
 }
 @Test
 public void netsalary() throws AssociateDetailsNotFound{
	Assert.assertNotEquals(88, payrollservices.calaculateNetSalary(111),1);
 }


}
	
 

