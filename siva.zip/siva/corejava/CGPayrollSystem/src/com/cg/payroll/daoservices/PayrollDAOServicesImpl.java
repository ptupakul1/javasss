package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollDAOServicesImpl implements PayrollDAOServices {
public static HashMap <Integer,Associate> associatelist=new HashMap<>();

	public int insertAssociate(Associate associate){
		associate.setAssociateID(PayrollUtility.ASSOCIATE_ID_COUNTER);
		associatelist.put(PayrollUtility.ASSOCIATE_ID_COUNTER++, associate);
		return associate.getAssociateID();
	}
	public boolean updateAssociate(Associate associate){
		if(associatelist.replace(associate.getAssociateID(),associate)!=null)
			return true;
		
		return false;
	}

	public boolean deleteAssociate(int associateID){
		if(associatelist.remove(associateID)!=null)
		return true;
		return false;
	}


	public Associate getAssociate(int associateID){
		return associatelist.get(associateID);
	}

	public List<Associate> getAssociates(){
		return new ArrayList(associatelist.values());
	}
}


