package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingImpl implements GreetingServices{

	public void sayHello(String personName) {
		System.out.println("Hello");
		
	}

	public void sayGoodBye(String personName) {
		
		System.out.println("bye");
	}

	

}
