package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.hibernate.Transaction;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
import com.mysql.jdbc.PreparedStatement;

@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
@Autowired
private EntityManagerFactory entityManagerFactory;
	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		EntityManager entityManager =entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateID();
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	entityManager.getTransaction().begin();
	 entityManager.merge(associate);
	entityManager.getTransaction().commit();
	return true;
	}

	@Override
	public boolean deleteAssociate(int associateID) throws SQLException {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Associate associate= entityManager.find(Associate.class, associateID);
		if(associate !=null){
			entityManager.getTransaction().begin();
			entityManager.remove(associate);
			entityManager.flush();
			entityManager.getTransaction().commit();
			return true;
		}
		return false;
	}

	@Override
	public Associate getAssociate(int associateID) throws SQLException {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		return entityManager.find(Associate.class, associateID);
	}

	@Override
	public List<Associate> getAssociates() throws SQLException {
	
	TypedQuery<Associate>querry=entityManagerFactory.createEntityManager().createQuery("from Associate",Associate.class);
		return querry.getResultList();
	}
	


}
