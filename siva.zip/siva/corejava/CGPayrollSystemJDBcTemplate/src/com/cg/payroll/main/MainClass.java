package com.cg.payroll.main;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.serial.Serialization;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;
public class MainClass {

	public static void main(String[] args) {			
		try {
		ApplicationContext applicationContext= new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices) applicationContext.getBean("payrollServices");
			//System.out.println(payrollServices.acceptAssociateDetails("df", "d", "sd", "sd", "SD", "DS", 44, 4, 4, 4, 4, "D", "DF"));
		//System.out.println(payrollServices.calaculateNetSalary(111));
		//System.out.println(payrollServices.getAssociateDetails(111));
		
			
		
		//System.out.println(payrollServices.updateAssociatedetails(111, "siva",	"Prasad", "emailId", "department", "designation", "pancard", 444444, 888, 44, 7777,12345, "bankName", "ifscCode"));
		 //System.out.println(payrollServices.deleteAssociate(111));
		 System.out.println(payrollServices.getAllAssociatesDetails());
		} catch (PayrollServicesDownException e) {
			e.printStackTrace();
		}
		
	}
}



