package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
import com.mysql.jdbc.PreparedStatement;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {

	private JdbcTemplate jdbcTemplate;


	public PayrollDAOServicesImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}



	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		
		jdbcTemplate.update("insert into associate(yearlyInvestmentUnder80C,firstName, lastName, department, designation, pancard,emailId) values(?,?,?,?,?,?,?)",associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId());
		int associateID=jdbcTemplate.queryForObject("select max(associateID)from associate", Integer.class);
		jdbcTemplate.update("insert into  salary(associateID,basicSalary, epf, companyPf) values(?,?,?,?)",associateID,associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf());
		jdbcTemplate.update("insert into  bankdetails(associateID,accountNumber, bankName, ifscCode) values(?,?,?,?)",associateID,associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode());

		return associateID;
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		jdbcTemplate.update("update associate set yearlyInvestmentUnder80C=?,firstName=?, lastName=?, department=?, designation=?, pancard=?,emailId=? where associateID=?",associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId(),associate.getAssociateID());
		jdbcTemplate.update("update  salary set basicSalary=?, epf=?, companyPf=? where associateID=? ",associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf(),associate.getAssociateID());
		jdbcTemplate.update("update  bankdetails set accountNumber=?, bankName=?, ifscCode=?  where associateID=?",associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode(),associate.getAssociateID());
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateID) throws SQLException {
		jdbcTemplate.update("delete from associate where associateID=?",associateID);
		return true;
	}

	@Override
	public Associate getAssociate(int associateID) throws SQLException {

		String s="select * from associate where associateID=?";
		Associate associate=(Associate) jdbcTemplate.queryForObject(s,new Object[] { associateID },new BeanPropertyRowMapper(Associate.class));
		String sss="select * from bankdetails where associateID=?";
		associate.setBankdetails((BankDetails) jdbcTemplate.queryForObject(sss,new Object[] { associateID },new BeanPropertyRowMapper(BankDetails.class)));getClass();
		String ss="select * from salary where associateID=?";
		associate.setSalary( (Salary) jdbcTemplate.queryForObject(ss, new BeanPropertyRowMapper(Salary.class),associateID));
		return associate;
	}

	@Override
	public List<Associate> getAssociates() throws SQLException {
		List<Associate>a=new ArrayList<>();
		a=(List<Associate>) jdbcTemplate.query("select * from associate inner join salary on salary.associateID=associate.associateID   inner join bankdetails on  bankdetails.associateID=associate.associateID",new Object[]{},  new BeanPropertyRowMapper(Associate.class));
		System.out.println(a);
		return null;
	}


}
