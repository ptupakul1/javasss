package com.cg.payroll.main;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.serial.Serialization;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;
public class MainClass {

	public static void main(String[] args) throws IOException, ClassNotFoundException, AssociateDetailsNotFound{			
	     try {
				PayrollUtility.getDBConnection();
				PayrollServices payrollServicesImpl=new PayrollServicesImpl();
		         System.out.println(payrollServicesImpl.acceptAssociateDetails("sdf", "sd", "fd", "SD", "sd", "ds", 55	, 100,5,5,4444,"SD	", "SD"));
			     
			
			System.out.println(payrollServicesImpl.updateAssociatedetails(111, "siva", "prasad", "t,pp", "javaa", "df", "DDDDD", 1200, 10000, 25, 25, 123456, "hdfc", "GGJ1234"));	
			   System.out.println(payrollServicesImpl.getAllAssociatesDetails());
			   			//System.out.println(payrollServicesImpl.getAssociateDetails(111));
				//System.out.println(payrollServicesImpl.deleteAssociate(111));
			} catch (PayrollServicesDownException e) {
				
				System.out.println(e.getMessage());
			}
			
		
	}
}



