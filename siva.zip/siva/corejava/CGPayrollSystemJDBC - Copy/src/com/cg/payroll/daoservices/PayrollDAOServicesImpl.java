package com.cg.payroll.daoservices;
import java.security.interfaces.RSAKey;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	private Connection con=null;
	public PayrollDAOServicesImpl() throws PayrollServicesDownException {
		con=PayrollUtility.getDBConnection();
	}
	@Override
	public int insertAssociate(Associate associate) throws SQLException   {
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("insert into associate(yearlyInvestmentUnder80C,firstName,lastName,emailId,department,designation,pancard) value(?,?,?,?,?,?,?)");
			pstmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(5, associate.getDepartment());
			pstmt1.setString(6, associate.getDesignation());
			pstmt1.setString(7, associate.getPancard());
			pstmt1.setString(4, associate.getEmailId());
			pstmt1.executeUpdate();
			PreparedStatement pstmt2=con.prepareStatement("select max(associateID) from associate");
			ResultSet r=pstmt2.executeQuery();
			r.next();
			int associateID=r.getInt(1);
			PreparedStatement pstmt3 = con.prepareStatement("insert into Salary(associateID,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt3.setInt(1, associateID);
			pstmt3.setDouble(2, associate.getSalary().getBasicSalary());
			pstmt3.setDouble(3, associate.getSalary().getEpf());
			pstmt3.setDouble(4, associate.getSalary().getCompanyPf());
			pstmt3.executeUpdate();

			PreparedStatement pstmt4 = con.prepareStatement("insert into BankDetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			pstmt4.setInt(1, associateID);
			pstmt4.setInt(2, associate.getBankdetails().getAccountNumber());
			pstmt4.setString(3, associate.getBankdetails().getBankName());
			pstmt4.setString(4, associate.getBankdetails().getIfscCode());

			pstmt4.executeUpdate();
			con.commit();
			return associateID;

		} catch (SQLException e) {
			con.rollback();
			throw e;

		}finally{
			con.setAutoCommit(true);
		}
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("update  associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,emailId=?,department=?,designation=?,pancard=? where associateID=?");
			pstmt1.setInt(8, associate.getAssociateID());
			pstmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(5, associate.getDepartment());
			pstmt1.setString(6, associate.getDesignation());
			pstmt1.setString(7, associate.getPancard());
			pstmt1.setString(4, associate.getEmailId());

			int i = pstmt1.executeUpdate();

			PreparedStatement pstmt2 = con.prepareStatement("update Salary set basicSalary=?,epf=?,companyPf=? where associateID=?");
			pstmt2.setDouble(1, associate.getSalary().getBasicSalary());
			pstmt2.setDouble(2, associate.getSalary().getEpf());
			pstmt2.setDouble(3, associate.getSalary().getCompanyPf());
			pstmt2.setInt(4, associate.getAssociateID());
			pstmt2.executeUpdate();
			PreparedStatement pstmt4 = con.prepareStatement("update  BankDetails set accountNumber=?,bankName=?,ifscCode=? where associateID=?");
			pstmt4.setInt(4, associate.getAssociateID());
			pstmt4.setInt(1, associate.getBankdetails().getAccountNumber());
			pstmt4.setString(2, associate.getBankdetails().getBankName());
			pstmt4.setString(3, associate.getBankdetails().getIfscCode());
			pstmt4.executeUpdate();
			con.commit();
			System.out.println(i);
			if(i!=0)
				return true;
			return false;
		} catch (SQLException e) {

			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
		}
	}

	@Override
	public boolean deleteAssociate(int associateID) throws SQLException {
		try{
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("delete from associate where associateID=?");
			pstmt1.setInt(1, associateID);
			pstmt1.executeUpdate();
			con.commit();
			return true;
		}catch (SQLException e) {
			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
		}
	}


	@Override
	public Associate getAssociate(int associateID) throws SQLException {

		try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1=con.prepareStatement("select * from  associate where associateID=?");
			pstmt1.setInt(1, associateID);
			ResultSet r=pstmt1.executeQuery();
			PreparedStatement pstmt2=con.prepareStatement("select * from bankdetails where associateID=?");
			pstmt2.setInt(1, associateID);
			ResultSet r2=pstmt2.executeQuery();
			PreparedStatement pstmt3=con.prepareStatement("select * from salary where associateID=?");
			pstmt3.setInt(1, associateID);
			ResultSet r3=pstmt3.executeQuery();
			if(r.next()&&r2.next()&&r3.next()){
				con.commit();
				return new Associate(r.getInt("associateID"),r.getInt("yearlyInvestmentUnder80C"), r.getString("firstName"),r.getString("lastName"), r.getString("department"), r.getString("designation"), r.getString("pancard"), r.getString("emailId"), new Salary(r3.getDouble("basicSalary"), r3.getDouble("conveyenceAllowance"), r3.getDouble("otherAllowance"), r3.getDouble("personalAllowance"), r3.getDouble("monthlyTax"), r3.getDouble("epf"), r3.getDouble("companyPf"), r3.getDouble("gratuity"), r3.getDouble("grossSalary"), r3.getDouble("netSalary"), r3.getDouble("hra")), new BankDetails(r2.getInt("accountNumber"), r2.getString("bankName"),r2.getString("ifscCode")));
			}

			return null;
		} catch (SQLException e) {

			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
		}
	}


	@Override
	public List<Associate> getAssociates()throws SQLException {
		try{
			List<Associate>associate=new ArrayList<>();

			PreparedStatement pstmt1=con.prepareStatement("select * from  associate ");
			ResultSet r=pstmt1.executeQuery();
			PreparedStatement pstmt2=con.prepareStatement("select * from bankdetails ");
			ResultSet r2=pstmt2.executeQuery();
			PreparedStatement pstmt3=con.prepareStatement("select * from salary ");
			ResultSet r3=pstmt3.executeQuery();
			while(r.next()&&r2.next()&&r3.next()){
				associate.add( new Associate(r.getInt("associateID"),r.getInt("yearlyInvestmentUnder80C"), r.getString("firstName"),r.getString("lastName"), r.getString("department"), r.getString("designation"), r.getString("pancard"), r.getString("emailId"), new Salary(r3.getDouble("basicSalary"), r3.getDouble("conveyenceAllowance"), r3.getDouble("otherAllowance"), r3.getDouble("personalAllowance"), r3.getDouble("monthlyTax"), r3.getDouble("epf"), r3.getDouble("companyPf"), r3.getDouble("gratuity"), r3.getDouble("grossSalary"), r3.getDouble("netSalary"), r3.getDouble("hra")), new BankDetails(r2.getInt("accountNumber"), r2.getString("bankName"),r2.getString("ifscCode"))));

			}
			return associate;
		}
		catch (SQLException e) {

			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
		}
	}
}


