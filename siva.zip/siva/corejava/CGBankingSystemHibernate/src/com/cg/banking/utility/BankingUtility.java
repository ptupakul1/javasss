package com.cg.banking.utility;

public class BankingUtility {

}
