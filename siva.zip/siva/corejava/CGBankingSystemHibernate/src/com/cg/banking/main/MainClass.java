package com.cg.banking.main;

import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		 try {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
	     BankingServices bankingServices=(BankingServices) applicationContext.getBean("bankingServices");
	    
	  System.out.println(bankingServices.acceptCustomerDetails("sss", "sd", "sd", "sad", "sd", "localAddressState", 889, "homeAddressCity", "homeAddressState", 888));
//	    System.out.println(bankingServices.acceptCustomerDetails("sss", "sd", "sd", "sad", "sd", "localAddressState", 889, "homeAddressCity", "homeAddressState", 888));
//	    
    System.out.println(bankingServices.openAccount(1112, "Savings", 800));
//	     System.out.println(bankingServices.accountStatus(1, 1));
//	    System.out.println(bankingServices.withdrawAmount(1, 1, 1000, 123));
//		System.out.println(bankingServices.depositAmount(1, 1, 200));
//		System.out.println(bankingServices.generateNewPin(1, 1));
//		System.out.println(bankingServices.changeAccountPin(1, 1, 1234, 1239));
//		System.out.println(bankingServices.getAccountDetails(1, 1));
//	   System.out.println(bankingServices.getCustomerDetails(1));
//	   System.out.println(bankingServices.getAllCustomerDetails());
//	  System.out.println(bankingServices.removecustomer(1));
//	  System.out.println(bankingServices.closeAccount(1, 1));
		 } catch (BankingServicesDownException | CustomerNotFoundException | InvalidAmountException | InvalidAccountTypeException e) {
			System.out.println(e);
			
		}
	     
	     
		
	}
}