package com.cg.banking.daoservices;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

@Component(value="bankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	@Override
	public int insertCustomer(Customer customer) {
		session = sessionFactory.openSession();
		org.hibernate.Transaction tx = null;
		Integer customerId=null;
		try {
			tx =  session.beginTransaction();
			customerId = (Integer) session.save(customer); 
			tx.commit();
			return customerId;
		} catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace(); 
			throw e;
		} finally {
			session.close(); 
		}

	} 
	@Override
	public long insertAccount(int customerId, Account account) {
		Customer customer=getCustomer(customerId);
		session=sessionFactory.openSession();
		org.hibernate.Transaction tran=null;

		long aID=0;
		try{

			if(customer!=null){
				tran=session.beginTransaction();
				account.setCustomer(customer);
				account.setStatus("Active");
				account.setPinNumber(generatePin(customerId, account));
				Transaction transaction=new Transaction(account.getAccountBalance(), "Deposit");
				aID=(long) session.save(account);
				transaction.setAccount(account);
				session.save(transaction);
				
				tran.commit();
			}
			return aID;
		}
		catch (HibernateException e) {
			tran.rollback();
			throw e;
		} 
		finally{
			session.close();
		}
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		session= sessionFactory.openSession();
		Customer customer=(Customer) session.get(Customer.class, customerId);
		
		org.hibernate.Transaction tran=null;

		try {						
			if(customer!=null){
				tran=session.beginTransaction();
				session.merge(account);
				tran.commit();
		}
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			tran.rollback();
			throw e;
		}
		finally{
			session.close();
		}
	}

	@Override
	public int generatePin(int customerId, Account account) {
		session= sessionFactory.openSession();
		org.hibernate.Transaction tran;
		int randomPIN = (int)(Math.random()*9000)+1000;
		tran=session.beginTransaction();
		account.setPinNumber(randomPIN);
		tran.commit();
		return randomPIN;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		Account account=getAccount(customerId, accountNo);
		session=sessionFactory.openSession();
		org.hibernate.Transaction tran=null;

		try {

			if(account!=null){
				tran=session.beginTransaction();
				transaction.setAccount(account);
				session.save(transaction);
				tran.commit();
			}
			return true;
		}catch (HibernateException e) {
			e.printStackTrace();
			tran.rollback();
			throw e;
		}finally{
			session.close();
		}
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		session=sessionFactory.openSession();
		Customer customer=(Customer) session.get(Customer.class, customerId);
		org.hibernate.Transaction tran=null;
		try{
			
			if(customer!=null){
				tran=session.beginTransaction();
				session.delete(customer);
				tran.commit();
			}
			return true;
		}catch (HibernateException e) {
			e.printStackTrace();
			tran.rollback();
			throw e;
		}finally {
			session.close();
		}


	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Account account=(Account)session.get(Account.class,accountNo);
		org.hibernate.Transaction tran=null;
		try{
			if(account!=null){
				tran=session.beginTransaction();
				session.delete(account);
				tran.commit();
			}
			return true;
		}catch (HibernateException e) {
			e.printStackTrace();
			tran.rollback();
			throw e;
		}finally {
			session.close();
		}


	}

	@Override
	public Customer getCustomer(int customerId) {
		session=sessionFactory.openSession();
		Customer customer=(Customer) sessionFactory.openSession().get(Customer.class, customerId);
		session.close();
		return customer;				
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		Customer customer=getCustomer(customerId);
		 session =sessionFactory.openSession();
		 org.hibernate.Transaction tran=null;
			if(customer!=null){
			tran=session.beginTransaction();
			Account account=(Account)sessionFactory.openSession().get(Account.class,accountNo);
			account.setCustomer(customer);
			tran.commit();
			session.close();
			return account;
		}
		session.close();
		return null;
	}
	@Override
	public List<Customer> getCustomers() {
		return sessionFactory.openSession().createQuery("from Customer").list();
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return sessionFactory.openSession().createQuery("from Account").list();
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return sessionFactory.openSession().createQuery("from Transaction").list();
	}

}


