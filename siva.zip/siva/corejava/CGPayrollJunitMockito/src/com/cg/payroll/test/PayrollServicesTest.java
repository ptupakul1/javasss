package com.cg.payroll.test;






import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

//import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {
 private static PayrollServices payrollservices;
 private static PayrollDAOServices mockdaoservices;
 
 @BeforeClass
 public static void setUpTestEnv(){
	mockdaoservices =Mockito.mock(PayrollDAOServices.class);
	 payrollservices=new PayrollServicesImpl(mockdaoservices);
	 }
 @AfterClass
 public static void tearDownTestEnv(){
	 payrollservices=null;
 }
 @Before
 public void setUpMockData(){
	    Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 150000,"siva","prasad", "department", "designation"," pancard"," emailId@email", new Salary(15000, 52, 52), new	BankDetails(1234,"HDFC","HDFC777")); 
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 180000,"ravi","prasad", "department", "designation"," pancard"," siva@email", new Salary(18000,42, 72), new	BankDetails(1278,"HDFC","HDFC5555")); 
		Associate associate3=new Associate(10000, "s", "s", "s", "s", "s", "s", new Salary(1000, 2, 2), new BankDetails(1234, "s", "s"));
		List<Associate>a=new ArrayList<>();
	    a.add(associate1);
	    a.add(associate2);
	    a.add(associate3);
	   Mockito.when(mockdaoservices.getAssociate(111)).thenReturn(associate1);
	   Mockito.when(mockdaoservices.getAssociate(112)).thenReturn(associate2);
	   Mockito.when(mockdaoservices.getAssociate(11)).thenReturn(null);
       Mockito.when(mockdaoservices.insertAssociate(associate3)).thenReturn(113);
       Mockito.when(mockdaoservices.deleteAssociate(111)).thenReturn(true);
       Mockito.when(mockdaoservices.deleteAssociate(112)).thenReturn(true);
       Mockito.when(mockdaoservices.deleteAssociate(11)).thenReturn(false);
       
 }
 @After
 public void tearDownMockData(){
	 payrollservices.getAllAssociatesDetails().clear();
	 PayrollUtility.ASSOCIATE_ID_COUNTER=111;
	 Mockito.reset(mockdaoservices);
 }
 @Test
 public void acceptAssocaiteDetailsForvalidData(){
	 Associate a=new Associate(10000, "s", "s", "s", "s", "s", "s", new Salary(1000, 2, 2), new BankDetails(1234, "s", "s"));
	assertEquals(113,payrollservices.acceptAssociateDetails("s", "s", "s", "s", "s", "s",10000, 1000, 2, 2, 1234, "s", "s"));
    Mockito.verify(mockdaoservices).insertAssociate(a);
 }
 @Test
 public void testAssociateDetails() throws AssociateDetailsNotFound{
	 Associate a=new Associate(111, 150000,"siva","prasad", "department", "designation"," pancard"," emailId@email", new Salary(15000, 52, 52), new	BankDetails(1234,"HDFC","HDFC777"));
	 Assert.assertEquals(a, payrollservices.getAssociateDetails(111));
	 Mockito.verify(mockdaoservices).getAssociate(111);
 }
 @Test(expected=AssociateDetailsNotFound.class)
 public void testAssociateDetails1() throws AssociateDetailsNotFound{
	  payrollservices.getAssociateDetails(11);
	 Mockito.verify(mockdaoservices).getAssociate(11);
	 
 }
 @Test
 public void testDeleteAssociate() throws AssociateDetailsNotFound{
	Assert.assertTrue(payrollservices.deleteAssociate(111));
	 Mockito.verify(mockdaoservices).deleteAssociate(111);
 }
 @Test(expected=AssociateDetailsNotFound.class)
 public void testDeleteAssociate1() throws AssociateDetailsNotFound{
	payrollservices.deleteAssociate(11);
	Mockito.verify(mockdaoservices).deleteAssociate(11);
	 
 }
 @Test
 public void acceptAssocaiteDetailsForInvalidData(){
	 Associate a=new Associate(10000, "l", "s", "s", "s", "s", "s", new Salary(1000, 2, 2), new BankDetails(1234, "s", "s"));
		assertNotEquals(113,payrollservices.acceptAssociateDetails("l", "s", "s", "s", "s", "s",10000, 1000, 2, 2, 1234, "s", "s"));
	   Mockito.verify(mockdaoservices).insertAssociate(a);
 }
 @Test
 public void netsalary() throws AssociateDetailsNotFound{
	
 }


}
	
 

