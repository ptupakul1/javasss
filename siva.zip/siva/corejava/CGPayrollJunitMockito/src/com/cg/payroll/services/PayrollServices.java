package com.cg.payroll.services;

import java.util.List;
import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;

public interface PayrollServices {

	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
			int accountNumber, String bankName, String ifscCode);//throw PayrollDowntimeException;

	double calaculateNetSalary(int associateID)throws AssociateDetailsNotFound;

	Associate getAssociateDetails(int associateID)throws AssociateDetailsNotFound;

	List<Associate> getAllAssociatesDetails();
    boolean deleteAssociate(int associateId)throws AssociateDetailsNotFound;
    public boolean updateAssociatedetails(int associateID,String firstName, String lastName,String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,double basicSalary,double epf, double companyPf,int accountNumber, 
			String bankName, String ifscCode)throws AssociateDetailsNotFound;
}