package com.cg.employeeinheritance.main;

import com.cg.employeeinheritance.beans.CEmployee;
import com.cg.employeeinheritance.beans.Developer;
import com.cg.employeeinheritance.beans.Employee;
import com.cg.employeeinheritance.beans.PEmployee;
import com.cg.employeeinheritance.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
		/*Employee employee =new Employee(111,5000,"siva","prasad");
		employee.calculatetotalSalary();
		System.out.println(employee.toString());
		SalesManager salesmanager=new SalesManager(122,5000,"siva","prasad",12535);
		salesmanager.Dosale();
		salesmanager.calculatetotalSalary();
		System.out.println(salesmanager.toString());
		PEmployee pemployee=new PEmployee(133,5000,"siva","prasasd");
		pemployee.calculatetotalSalary();
		System.out.println(pemployee.toString());
		Developer developer=new Developer(11111, 5000, "siva", "sss", 3);
		developer.calculatetotalSalary();
		System.out.println(developer.toString());
		CEmployee cemployee=new CEmployee(1234,5000,"siva","prasad",55);
		cemployee.Deed();
		cemployee.calculatetotalSalary();
		System.out.println(cemployee.toString());*/
	    Employee employee =new PEmployee(111,5000,"siva","prasad");
	    employee.calculatetotalSalary();
	    System.out.println(employee);
	    employee =new CEmployee(5555,"ss","sd",55);
	    CEmployee emp=(CEmployee) employee;
	    emp.Deed();
	    employee.calculatetotalSalary();
	    System.out.println(employee);
	     
	   
	}

}
