package com.cg.employeeinheritance.beans;

public final class SalesManager extends PEmployee {
	private int salesamount,commission;
	public SalesManager(){
		super();
	}
	
	

	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
		
	}
public SalesManager(int employeeId, int basicSalary, String firstName, String lastName, int salesamount)
			 {
		super(employeeId, basicSalary, firstName, lastName);
		this.salesamount = salesamount;
		
	}



	public int getSalesamount() {
		return salesamount;
	}

	public void setSalesamount(int salesamount) {
		this.salesamount = salesamount;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}
	public void calculatetotalSalary() {
		super.calculatetotalSalary();
		commission=2*salesamount/100;
		setTotalSalary(commission+this.getTotalSalary());
	}

	@Override
	public String toString() {
		return super.toString()+ "SalesManager [salesamount=" + salesamount + ", commission=" + commission + "]";
	}
	
	public void Dosale(){
		System.out.println("sales done");
	}
}
