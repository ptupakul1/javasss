package com.cg.employeeinheritance.beans;

public final class Developer extends PEmployee {
	private int noOfprojects,incentives;
	public Developer(){
		super();
	}
		public Developer(int employeeId, int basicSalary,  String firstName, String lastName) {
		super(employeeId, basicSalary,  firstName, lastName);
		
		}
		public Developer(int employeeId, int basicSalary,  String firstName, String lastName,
				int noOfprojects ) {
			super(employeeId, basicSalary,  firstName, lastName);
			this.noOfprojects = noOfprojects;
			
		}
		public int getNoOfprojects() {
			return noOfprojects;
		}
		public void setNoOfprojects(int noOfprojects) {
			this.noOfprojects = noOfprojects;
		}
		public int getIncentives() {
			return incentives;
		}
		public void setIncentives(int incentives) {
			this.incentives = incentives;
		}
		@Override
		public void calculatetotalSalary() {
			super.calculatetotalSalary();
			 incentives=this.noOfprojects*500;
			 setTotalSalary(this.getTotalSalary()+incentives);
			 
			 
		}
		@Override
		public String toString() {
			return super.toString()+ "Developer [noOfprojects=" + noOfprojects + ", incentives=" + incentives + "]";
		}
		
 
}
