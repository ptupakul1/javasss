package com.cg.employeeinheritance.beans;

public final class CEmployee extends Employee{
	private int hrs,variablepay;
	public CEmployee(){
		super();
	}
	public CEmployee(int employeeId,  String firstName, String lastName) {
		super(employeeId, firstName, lastName);
		
	}
	public CEmployee(int employeeId, String firstName, String lastName, int hrs) {
		super(employeeId, firstName, lastName);
		this.hrs = hrs;
		
	}
	public int getHrs() {
		return hrs;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public int getVariablepay() {
		return variablepay;
	}
	public void setVariablepay(int variablepay) {
		this.variablepay = variablepay;
	}
	@Override
	public void calculatetotalSalary() {
		this.variablepay=this.hrs*5000;
	}
	@Override
	public String toString() {
		return super.toString()+ "CEmployee hrs=" + hrs + ", variablepay=" + variablepay ;
	}
	
     public void Deed(){
    	 System.out.println("signed");
     }
}
