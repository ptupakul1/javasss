package com.cg.io.serial;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.io.beans.Associate;

public class SerializationDemo {
  public static void doSerialization(File file) throws FileNotFoundException, IOException{
	  Associate a=new Associate(444, 44, "dfs", "df", "sda", "sd", "sdd", "ds");
	  Associate b=new Associate(4, 44, "dfstjf", "dguygf", "sda", "sd", "sdd", "ds");
	  try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
    	dest.writeObject(a);   
    	dest.writeObject(b);
      }
  }
  public static void doDeSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException{
	 try(ObjectInputStream src= new ObjectInputStream(new FileInputStream(file))){
		 Associate a=(Associate)src.readObject();
		 //Associate b=(Associate)src.readObject();
		 System.out.println(a);
		 System.out.println(a);
		 
	 }
		 
  }
}
