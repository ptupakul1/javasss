package com.cg.io.beans;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo  {
	public static void byteReadWrite(File fromfile,File tofile) throws IOException{
		try(BufferedInputStream scr=new BufferedInputStream( new FileInputStream(fromfile))){
			try(BufferedOutputStream dest=new BufferedOutputStream( new FileOutputStream(tofile))){
				
					//1st way
		        	int i=0;
		        	while((i=scr.read())!=-1){

		        		System.out.print((char)i);
		        		dest.write(i);
		        	}
		        	/*//2nd way
		        	byte []b=new byte[(int)fromfile.length()];
		        	scr.read(b);
		        	System.out.println(new String(b));*/
				}
			}

		}


		/*FileInputStream scr=new FileInputStream(fromfile);
        	FileOutputStream dest=new FileOutputStream(tofile);
        	//1st way
        	int i=0;
        	while((i=scr.read())!=-1){

        		System.out.print((char)i);
        		dest.write(i);
        	}
        	//2nd way
        	byte []b=new byte[(int)fromfile.length()];
        	scr.read(b);
        	System.out.println(new String(b));*/


	}

