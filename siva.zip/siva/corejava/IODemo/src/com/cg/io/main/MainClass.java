package com.cg.io.main;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import com.cg.io.beans.ByteStreamDemo;
import com.cg.io.serial.SerializationDemo;
public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException {
	try { 
		File file=new File("d:\\javacrosskilling\\text.txt");
		//File file2=new File("d:\\Textfile2.txt");
		
		if(!file.exists())
		file.createNewFile();

		//if(!file2.exists())
		//	file2.createNewFile();
		SerializationDemo.doSerialization(file);
		SerializationDemo.doDeSerialization(file);
		
		
	} catch (IOException e) {
		e.printStackTrace();
	}
	}	

	}


