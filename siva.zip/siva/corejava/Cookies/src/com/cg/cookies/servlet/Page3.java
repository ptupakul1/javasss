package com.cg.cookies.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/Page3")
public class Page3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    	public void init()  {
		
	}

	
	public void destroy() {
	
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter wr=response.getWriter();
		String city =request.getParameter("city");
		String state=request.getParameter("state");	
		Cookie [] cookies = request.getCookies();
		String firstName ="" , lastName="";
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
		}
	
		
		wr.print("<html>");
		wr.println("<body>");
		wr.println("<div align='center'>");
		wr.println("<form name='f3'method='post'action='Page4'>");
		wr.println("<table>");
		wr.println("<tr>");
		wr.println("<td> firstName:</td><td>"+firstName+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>lastName:</td><td>"+lastName+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>city:</td><td>"+city+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>state:</td><td>"+state+"</td></tr>");
		wr.println("<tr>");
        wr.println("<td> Enter EmailID:</td>");
        wr.println("<td><input type='email'name='email'></td>");
        wr.println("</tr>");
        wr.println("<tr>");
        wr.println("<td> Enter PhoneNo:</td>");
        wr.println("<td><input type='phone'name='phoneNo'></td>");
        wr.println("</tr>");
        wr.println("<tr align ='center'>");
        wr.println("<td><input type='submit'></td>");
        wr.println("</tr>");
		wr.println("</table>");
		wr.println("</form>");
		wr.println("</div>");
		wr.println("</body>");
		wr.println("</html>");
		Cookie c1 = new  Cookie("firstName",firstName);
		Cookie c2 = new Cookie("lastName" ,lastName);
		response.addCookie(c1);
		response.addCookie(c2);
		Cookie c3 = new  Cookie("city",city);
		Cookie c4 = new Cookie("state" ,state);
		response.addCookie(c3);
		response.addCookie(c4);
	}

}
