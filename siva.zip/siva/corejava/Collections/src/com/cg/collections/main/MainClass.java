package com.cg.collections.main;

import java.util.ArrayList;
import java.util.List;

import com.cg.collections.LIstClassDemo;
import com.cg.collections.MyGenricClass;


public class MainClass {

	public static void main(String[] args) {
		LIstClassDemo arrayList=new LIstClassDemo();
          arrayList.arrayList();
		MyGenricClass<Integer> i= new MyGenricClass<Integer>(1,2);
		//MyGenricClass<String> j= new MyGenricClass<String>("1","5");
		ArrayList<Integer>in=new ArrayList<>();
		in.add(4);
		in.add(5);
		in.add(8);
		dll(in);
		ArrayList<String>s=new ArrayList<>();
		s.add("d");
		s.add("dd");
		s.add("80");
		dll(s);
		}
		public static void dll(ArrayList<?> t ){
			for (Object obj : t) {
				System.out.println(obj);
			}
		}
		
	

}
