package com.cg.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.cg.collections.beans.Customer;

public class LIstClassDemo {
	public static void arrayList(){
		ArrayList<String> str=new ArrayList<>();
		//insert
		str.add("siva");
		str.add("s");
		str.add("sia");
		str.add("va");
		//iteration
		/*Iterator<String> iterator=str.iterator();
		while (iterator.hasNext()) {
			String	s =  iterator.next();
			System.out.println(s);
		}*/
		
			//search
			System.out.println(str.contains("siva"));
			Collections.sort(str);
			System.out.println(str);
			ArrayList<Customer> customer=new ArrayList<>();
			customer.add(new Customer(111, "sdsd", "fjh"));
			customer.add(new Customer(115, "dfgsgsdsd", "ffdjkdkjh"));
			customer.add(new Customer(118, "dsivafgsgsdsd", "ffdjkprasaddkjh"));
			//Collections.sort(customer);
			Collections.sort(customer,new CustomerComaprator());
			System.out.println(customer);
			
		
	}
	
	

}
