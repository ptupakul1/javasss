package com.cg.collections;

import java.io.StringReader;

public class MyGenricClass<T extends Number> {
private T a,b;

public MyGenricClass(T a, T b) {
	super();
	this.a = a;
	this.b = b;
}

public T getA() {
	return a;
}

public void setA(T a) {
	this.a = a;
}

public T getB() {
	return b;
}

public void setB(T b) {
	this.b = b;
}

}
