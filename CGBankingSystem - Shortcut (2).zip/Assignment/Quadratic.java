public class Quadratic{
	public static void main(String[] str){
		int a=1,b=2,c=1;
		double d=0,r1=0,r2=0;
		d=b*b-4*a*c;
		r1 = (-b + Math.sqrt(d))/(2*a);
                r2 = (-b - Math.sqrt(d))/(2*a);
		System.out.println(r1);
		System.out.println(r1);
	}
}