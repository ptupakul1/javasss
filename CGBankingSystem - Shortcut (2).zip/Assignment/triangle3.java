public class Triangle3{
	public static void main(String str[]){
		 for(int i = 5; i > 0; i--){
			for(int j = i; j > 0; j--){
			System.out.print("* ");
 			}
 		System.out.print("\n");
}

	}
}