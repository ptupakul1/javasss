public class Triangle6{
	public static void main(String str[]){
		for(int i = 1; i <= 5; i++){
			for(int j = 1; j <= 5 - i; j++) {
                			System.out.print("  ");
		}
		for(int k=1;k<=i;k++) {
			system.out.print(" * ");
		}
		System.out.print("\n");
		}
                  for(int i=4;i>=0;i--){
		for(int j=1;j<=4-i;j++){
		System.out.print(" ");
			for(int k=1;k<=i;k++){
			System.out.print(" * ");	
			}
		System.out.print("\n");
	}
}
}



