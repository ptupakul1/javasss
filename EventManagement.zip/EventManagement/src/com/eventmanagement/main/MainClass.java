package com.eventmanagement.main;

import com.eventmanagement.beans.Catering;
import com.eventmanagement.beans.Customer;
import com.eventmanagement.beans.Event;
import com.eventmanagement.beans.EventAddress;
import com.eventmanagement.beans.Menu;

public class MainClass {

	public static void main(String[] args) {
		Customer customer = new Customer("Mutyala Srivatsava", 8790532425l);
		EventAddress eventAddress = new EventAddress("Hyderabad", "Telangana", "India", 500018);
		Event event = new Event("Marriage", "25th Jan 2018", "1st Feb 2018", 2000000, 7, 2000);
		Catering catering = new Catering("Available", "Food", 1000000);
		Menu menu = new Menu("Veg Biryani", "Available", 150);
			System.out.println(customer.getMobileNo()+" "+eventAddress.getCity()+" "+event.getTypeofEvent()+" "+catering.getCateringStatus()+" "+menu.getNameofItem());
			
	}

}
