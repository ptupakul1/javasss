package com.cg.appcontext.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appcontext.beans.UserDetails;


@WebServlet("/Form2")
public class Form2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   

	
	public void init() {
		
	}

	
	public void destroy() {
	
	}

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		PrintWriter wr=response.getWriter();
		wr.println("<html>");
		wr.println("<body>");
		wr.println("<form action ='Form3' name='secondform' method='post'>");
		wr.println("<table>");
		wr.println("<tr>");
		wr.println("<td> FirstName:</td><td>" +firstName+"</td>");
		wr.println("</tr>");
		wr.println("<tr>");
		wr.println("<td> lastName:</td><td>" +lastName+"</td>");
	    wr.println("</tr>");
	    wr.println("<tr>");
        wr.println("<td> Enter City:</td>");
        wr.println("<td><input type='text'name='city'></td>");
        wr.println("</tr>");
        wr.println("<tr>");
        wr.println("<td> Enter State:</td>");
        wr.println("<td><input type='text'name='state'></td>");
        wr.println("</tr>");
        wr.println("<tr align ='center'>");
        wr.println("<td><input type='submit'></td>");
        wr.println("</tr>");
		wr.println("</table>");
		wr.println("</form>");
		wr.println("</body>");
		wr.println("</html>");
		UserDetails userDetails=new UserDetails(firstName, lastName);
		ServletContext context = getServletContext();
		context.setAttribute("userDetails", userDetails);
		
		
	}

}
