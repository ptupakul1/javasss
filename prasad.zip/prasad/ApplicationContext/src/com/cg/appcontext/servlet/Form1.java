package com.cg.appcontext.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Form1")
public class Form1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    
	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	          PrintWriter writer=response.getWriter();
	          writer.println("<html>");
	          writer.println("<body>");
	          writer.println("<div align='center'>");
	          writer.println("<form method='post'name='firstform'action='Form2'>");
	          writer.println("<table>");
	          writer.println("<tr>");
	          writer.println("<td> Enter FirstName:</td>");
	          writer.println("<td><input type='text'name=firstName></td>");
	          writer.println("</tr>");
	          writer.println("<tr>");
	          writer.println("<td> Enter LastName:</td>");
	          writer.println("<td><input type='text'name=lastName></td>");
	          writer.println("</tr>");
	          writer.println("<tr align ='center'>");
	          writer.println("<td><input type='submit'></td>");
	          writer.println("</tr>");
	          writer.println("</table>");
	          writer.println("</form>");
	          writer.println("</form>");
	          writer.println("</div>");
	          writer.println("</body>");
	          writer.println("</html>");
	}

	
	

}
