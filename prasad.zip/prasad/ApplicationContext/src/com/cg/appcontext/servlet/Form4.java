package com.cg.appcontext.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appcontext.beans.UserDetails;


@WebServlet("/Form4")
public class Form4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init()  {

	}


	public void destroy() {

	}


	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter wr=response.getWriter();

		String email =request.getParameter("email");
		String phoneNo=request.getParameter("phoneNo");	
		ServletContext context = getServletContext();
		UserDetails user=(UserDetails)context.getAttribute("userDetails");	
		wr.print("<html>");
		wr.println("<body>");
		wr.println("<div align='center'>");
		wr.println("<table>");
		wr.println("<tr>");
		wr.println("<td>FirstName:</td><td>"+user.getFirstName()+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>lastName:</td><td>"+user.getLastName()+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>city:</td><td>"+user.getCity()+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>state:</td><td>"+user.getState()+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>email:</td><td>"+ email+"</td></tr>");
		wr.println("<tr>");
		wr.println("<td>phoneNO:</td><td>"+  phoneNo+"</td>");
		wr.println("</tr>");
		wr.println("</table>");
		wr.println("</div>");
		wr.println("</body>");
		wr.println("</html>");
		

	}

}
