package com.cg.cookies.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/Page2")
public class Page2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
   

	
	public void init()  {
		
	}

	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		PrintWriter wr=response.getWriter();
		wr.println("<html>");
		wr.println("<body>");
		wr.println("<div align='center'>");
		wr.println("<form action ='Page3' name='secondform' method='post'>");
		wr.println("<table>");
		wr.println("<tr>");
		wr.println("<td> FirstName:</td><td>" +firstName+"</td>");
		wr.println("</tr>");
		wr.println("<tr>");
		wr.println("<td> lastName:</td><td>" +lastName+"</td>");
	    wr.println("</tr>");
	    wr.println("<tr>");
        wr.println("<td> Enter City:</td>");
        wr.println("<td><input type='text'name='city'></td>");
        wr.println("</tr>");
        wr.println("<tr>");
        wr.println("<td> Enter State:</td>");
        wr.println("<td><input type='text'name='state'></td>");
        wr.println("</tr>");
        wr.println("<tr align ='center'>");
        wr.println("<td><input type='submit'></td>");
        wr.println("</tr>");
		wr.println("</table>");
		wr.println("</form>");
		wr.println("</div>");
		wr.println("</body>");
		wr.println("</html>");
		Cookie c1 = new  Cookie("firstName",firstName);
		Cookie c2 = new Cookie("lastName" ,lastName);
		response.addCookie(c1);
		response.addCookie(c2);
		
	}

}
